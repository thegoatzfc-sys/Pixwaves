export class DeterministicNoise {
  private seed: number;

  constructor(seed = 12345) {
    this.seed = seed;
  }

  // Deterministic 2D random generator
  public hash2D(x: number, y: number): number {
    const sx = Math.sin(x * 12.9898 + y * 78.233 + this.seed) * 43758.5453123;
    return sx - Math.floor(sx);
  }

  // Smoothly interpolated 2D noise
  public noise2D(x: number, y: number): number {
    const ix = Math.floor(x);
    const iy = Math.floor(y);
    const fx = x - ix;
    const fy = y - iy;

    // Cubic smoothstep interpolation
    const ux = fx * fx * (3.0 - 2.0 * fx);
    const uy = fy * fy * (3.0 - 2.0 * fy);

    // Grid corner hashes
    const a = this.hash2D(ix, iy);
    const b = this.hash2D(ix + 1, iy);
    const c = this.hash2D(ix, iy + 1);
    const d = this.hash2D(ix + 1, iy + 1);

    // Bilinear interpolation
    return a * (1 - ux) * (1 - uy) +
           b * ux * (1 - uy) +
           c * (1 - ux) * uy +
           d * ux * uy;
  }

  // Fractal Brownian Motion (FBM) with multiple octaves
  public fbm2D(x: number, y: number, octaves = 3): number {
    let value = 0.0;
    let amplitude = 0.5;
    let frequency = 1.0;
    for (let i = 0; i < octaves; i++) {
      value += amplitude * this.noise2D(x * frequency, y * frequency);
      frequency *= 2.0;
      amplitude *= 0.5;
    }
    return value;
  }
}
