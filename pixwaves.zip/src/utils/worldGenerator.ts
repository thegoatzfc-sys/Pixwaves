import { DeterministicNoise } from './noise';
import { ResourceNode, WallType, ProtectiveWall, Enemy, Turret } from '../types';

export interface Chunk {
  cx: number;
  cy: number;
  layer: 'sky' | 'surface' | 'underground' | 'cavern' | 'underworld';
  biome: 'forest' | 'plains' | 'desert' | 'snow' | 'swamp' | 'jungle' | 'mountains';
  resources: ResourceNode[];
  backgroundWalls: { x: number; y: number; type: 'dirt' | 'stone' | 'obsidian' | 'cloud' }[];
  lavaPools: { x: number; y: number; width: number; height: number }[];
  hasGenerated: boolean;
  walls?: ProtectiveWall[];
  turrets?: Turret[];
  enemies?: Enemy[];
}

const TILE_SIZE = 60;
const CHUNK_TILES = 16;
const CHUNK_PIXELS = CHUNK_TILES * TILE_SIZE; // 960px

export class WorldGenerator {
  private noise: DeterministicNoise;

  constructor(seed = 98765) {
    this.noise = new DeterministicNoise(seed);
  }

  // Determine biome of a specific chunk coordinate in 2D space
  public getBiome(cx: number, cy: number): 'forest' | 'plains' | 'desert' | 'snow' | 'swamp' | 'jungle' | 'mountains' {
    // Generate temperature and elevation / humidity noise
    const temp = this.noise.noise2D(cx * 0.05, cy * 0.05); // 0 to 1 range
    const hum = this.noise.noise2D(cx * 0.05 + 24.5, cy * 0.05 + 71.9); // 0 to 1 range

    if (temp < 0.25) {
      return 'snow';
    }
    if (temp > 0.75) {
      if (hum < 0.35) return 'desert';
      return 'jungle';
    }
    // Moderate temperatures
    if (hum < 0.25) {
      return 'plains';
    }
    if (hum > 0.75) {
      return 'swamp';
    }
    // Forest / Mountains based on elevation noise
    const elev = this.noise.noise2D(cx * 0.08 + 120.3, cy * 0.08 + 50.1);
    if (elev > 0.7) {
      return 'mountains';
    }
    return 'forest';
  }

  // Procedurally generate a chunk for a given layer at (cx, cy)
  public generateChunk(
    cx: number,
    cy: number,
    layer: 'sky' | 'surface' | 'underground' | 'cavern' | 'underworld'
  ): Chunk {
    const chunkResources: ResourceNode[] = [];
    const bgWalls: { x: number; y: number; type: 'dirt' | 'stone' | 'obsidian' | 'cloud' }[] = [];
    const lava: { x: number; y: number; width: number; height: number }[] = [];

    const biome = this.getBiome(cx, cy);
    const startX = cx * CHUNK_PIXELS;
    const startY = cy * CHUNK_PIXELS;

    // We process each tile cell inside the 16x16 chunk
    for (let gy = 0; gy < CHUNK_TILES; gy++) {
      for (let gx = 0; gx < CHUNK_TILES; gx++) {
        const tileX = startX + gx * TILE_SIZE + TILE_SIZE / 2;
        const tileY = startY + gy * TILE_SIZE + TILE_SIZE / 2;
        const globX = cx * CHUNK_TILES + gx;
        const globY = cy * CHUNK_TILES + gy;

        // Form unique key per tile
        const tId = `res_${cx}_${cy}_${gx}_${gy}_${Math.floor(tileX)}`;

        switch (layer) {
          case 'sky': {
            // Floating islands generated via noise contours
            const density = this.noise.noise2D(globX * 0.12, globY * 0.12);
            bgWalls.push({ x: tileX, y: tileY, type: 'cloud' });

            if (density > 0.56) {
              // Solid Sky Block (indestructible cloud / starstone)
              const maxHp = 180;
              chunkResources.push({
                id: tId,
                type: Math.random() < 0.08 ? 'sky-crystal' : 'stone',
                x: tileX,
                y: tileY,
                width: TILE_SIZE,
                height: TILE_SIZE,
                health: maxHp,
                maxHealth: maxHp,
                respawnTime: null,
              });
            } else {
              // Open Sky space, occasionally generate star-chest or floating trees
              if (Math.random() < 0.006) {
                // Sky Crystal Vein
                chunkResources.push({
                  id: tId,
                  type: 'sky-crystal',
                  x: tileX,
                  y: tileY,
                  width: 48,
                  height: 48,
                  health: 300,
                  maxHealth: 300,
                  respawnTime: null,
                });
              } else if (Math.random() < 0.015 && density > 0.45) {
                // Living Sky-Wood tree
                chunkResources.push({
                  id: tId,
                  type: 'wood',
                  x: tileX,
                  y: tileY,
                  width: 50,
                  height: 50,
                  health: 60,
                  maxHealth: 60,
                  respawnTime: null,
                });
              }
            }
            break;
          }

          case 'surface': {
            // Surface is open terrain, great for building base.
            // Biomes transition smoothly
            bgWalls.push({ x: tileX, y: tileY, type: 'dirt' });

            // Ensure starter spawn chunk has a safe clear flat zone
            const isSpawnPoint = Math.abs(tileX) < 300 && Math.abs(tileY) < 300;

            if (!isSpawnPoint) {
              // Small copper/coal boulder veins on surface levels
              const boulderDensity = this.noise.noise2D(globX * 0.18, globY * 0.18);
              if (boulderDensity > 0.72) {
                chunkResources.push({
                  id: tId,
                  type: 'stone',
                  x: tileX,
                  y: tileY,
                  width: TILE_SIZE,
                  height: TILE_SIZE,
                  health: 120,
                  maxHealth: 120,
                  respawnTime: null,
                });
              } else if (boulderDensity > 0.68) {
                chunkResources.push({
                  id: tId,
                  type: Math.random() < 0.5 ? 'coal' : 'iron',
                  x: tileX,
                  y: tileY,
                  width: TILE_SIZE - 6,
                  height: TILE_SIZE - 6,
                  health: 100,
                  maxHealth: 100,
                  respawnTime: null,
                });
              } else {
                // Populate organic biome foliage and landmarks
                const rand = Math.random();
                if (biome === 'desert') {
                  if (rand < 0.02) {
                    // Cactus (styled as wood resource)
                    chunkResources.push({
                      id: tId,
                      type: 'wood',
                      x: tileX,
                      y: tileY,
                      width: 44,
                      height: 44,
                      health: 50,
                      maxHealth: 50,
                      respawnTime: null,
                    });
                  } else if (rand < 0.035) {
                    chunkResources.push({
                      id: tId,
                      type: 'stone',
                      x: tileX,
                      y: tileY,
                      width: 42,
                      height: 42,
                      health: 100,
                      maxHealth: 100,
                      respawnTime: null,
                    });
                  }
                } else if (biome === 'snow') {
                  if (rand < 0.03) {
                    // Frost Pine Trees
                    chunkResources.push({
                      id: tId,
                      type: 'wood',
                      x: tileX,
                      y: tileY,
                      width: 48,
                      height: 48,
                      health: 70,
                      maxHealth: 70,
                      respawnTime: null,
                    });
                  } else if (rand < 0.025) {
                    chunkResources.push({
                      id: tId,
                      type: 'stone',
                      x: tileX,
                      y: tileY,
                      width: 45,
                      height: 45,
                      health: 120,
                      maxHealth: 120,
                      respawnTime: null,
                    });
                  }
                } else if (biome === 'swamp') {
                  if (rand < 0.035) {
                    // Saturated Swamp Trees
                    chunkResources.push({
                      id: tId,
                      type: 'wood',
                      x: tileX,
                      y: tileY,
                      width: 50,
                      height: 50,
                      health: 80,
                      maxHealth: 80,
                      respawnTime: null,
                    });
                  } else if (rand < 0.02) {
                    // Mossy Stone Clusters
                    chunkResources.push({
                      id: tId,
                      type: 'stone',
                      x: tileX,
                      y: tileY,
                      width: 46,
                      height: 46,
                      health: 110,
                      maxHealth: 110,
                      respawnTime: null,
                    });
                  }
                } else if (biome === 'jungle') {
                  if (rand < 0.045) {
                    // Rich mahogany trees
                    chunkResources.push({
                      id: tId,
                      type: 'wood',
                      x: tileX,
                      y: tileY,
                      width: 52,
                      height: 52,
                      health: 80,
                      maxHealth: 80,
                      respawnTime: null,
                    });
                  } else if (rand < 0.015) {
                    // Jungle gold deposits
                    chunkResources.push({
                      id: tId,
                      type: 'gold' as any,
                      x: tileX,
                      y: tileY,
                      width: 40,
                      height: 40,
                      health: 140,
                      maxHealth: 140,
                      respawnTime: null,
                    });
                  }
                } else if (biome === 'plains') {
                  if (rand < 0.012) {
                    // Sparse birch tree
                    chunkResources.push({
                      id: tId,
                      type: 'wood',
                      x: tileX,
                      y: tileY,
                      width: 42,
                      height: 42,
                      health: 45,
                      maxHealth: 45,
                      respawnTime: null,
                    });
                  } else if (rand < 0.018) {
                    // Loose stones or clay
                    chunkResources.push({
                      id: tId,
                      type: 'stone',
                      x: tileX,
                      y: tileY,
                      width: 40,
                      height: 40,
                      health: 95,
                      maxHealth: 95,
                      respawnTime: null,
                    });
                  }
                } else if (biome === 'mountains') {
                  if (rand < 0.04) {
                    // Large Granite Boulders
                    chunkResources.push({
                      id: tId,
                      type: 'stone',
                      x: tileX,
                      y: tileY,
                      width: 54,
                      height: 54,
                      health: 220,
                      maxHealth: 220,
                      respawnTime: null,
                    });
                  } else if (rand < 0.015) {
                    // mountain iron veins
                    chunkResources.push({
                      id: tId,
                      type: 'iron',
                      x: tileX,
                      y: tileY,
                      width: 44,
                      height: 44,
                      health: 180,
                      maxHealth: 180,
                      respawnTime: null,
                    });
                  }
                } else {
                  // Forest Default
                  if (rand < 0.035) {
                    // Green Forest Oak
                    chunkResources.push({
                      id: tId,
                      type: 'wood',
                      x: tileX,
                      y: tileY,
                      width: 50,
                      height: 50,
                      health: 60,
                      maxHealth: 60,
                      respawnTime: null,
                    });
                  } else if (rand < 0.018) {
                    chunkResources.push({
                      id: tId,
                      type: 'stone',
                      x: tileX,
                      y: tileY,
                      width: 46,
                      height: 46,
                      health: 120,
                      maxHealth: 120,
                      respawnTime: null,
                    });
                  } else if (rand < 0.005) {
                    chunkResources.push({
                      id: tId,
                      type: 'iron',
                      x: tileX,
                      y: tileY,
                      width: 42,
                      height: 42,
                      health: 180,
                      maxHealth: 180,
                      respawnTime: null,
                    });
                  }
                }
              }

              // Occasional Cave Entrances on Surface (1 per 4 chunks average)
              if (gx === 8 && gy === 8) {
                const caveNoise = this.noise.hash2D(cx, cy);
                if (caveNoise < 0.4) {
                  chunkResources.push({
                    id: `portal_down_${cx}_${cy}`,
                    type: 'cave-entrance',
                    x: tileX,
                    y: tileY,
                    width: 70,
                    height: 70,
                    health: 99999,
                    maxHealth: 99999,
                    respawnTime: null,
                  });
                }
              }
            }
            break;
          }

          case 'underground': {
            // Earthy subterranean caves
            bgWalls.push({ x: tileX, y: tileY, type: 'dirt' });

            const caveFactor = this.noise.fbm2D(globX * 0.15, globY * 0.15, 3);
            if (caveFactor > 0.46) {
              // Solid subterranean block! Acts as a solid resource player must mine through
              const randType = Math.random();
              let bType: 'stone' | 'iron' | 'coal' = 'stone';
              let maxHp = 120;
              if (randType < 0.07) {
                bType = 'coal';
                maxHp = 80;
              } else if (randType < 0.12) {
                bType = 'iron';
                maxHp = 180;
              }

              chunkResources.push({
                id: tId,
                type: bType,
                x: tileX,
                y: tileY,
                width: TILE_SIZE,
                height: TILE_SIZE,
                health: maxHp,
                maxHealth: maxHp,
                respawnTime: null,
              });
            } else {
              // Open cave path tunnels. Occasional wood supports or mineshaft cabins
              if (Math.random() < 0.015) {
                // Leftover timber wood support poles
                chunkResources.push({
                  id: tId,
                  type: 'wood',
                  x: tileX,
                  y: tileY,
                  width: 24,
                  height: 55,
                  health: 40,
                  maxHealth: 40,
                  respawnTime: null,
                });
              }
            }

            // Up/Down Portals
            if (gx === 4 && gy === 4 && cx % 2 === 0 && cy % 2 === 0) {
              chunkResources.push({
                id: `portal_up_${cx}_${cy}`,
                type: 'stairs-up',
                x: tileX,
                y: tileY,
                width: 60,
                height: 60,
                health: 99999,
                maxHealth: 99999,
                respawnTime: null,
              });
            }
            if (gx === 12 && gy === 12 && cx % 2 === 0 && cy % 2 === 0) {
              chunkResources.push({
                id: `portal_down_${cx}_${cy}`,
                type: 'stairs-down',
                x: tileX,
                y: tileY,
                width: 60,
                height: 60,
                health: 99999,
                maxHealth: 99999,
                respawnTime: null,
              });
            }
            break;
          }

          case 'cavern': {
            // Dark stone caverns
            bgWalls.push({ x: tileX, y: tileY, type: 'stone' });

            const caveFactor = this.noise.fbm2D(globX * 0.14, globY * 0.14, 3);
            if (caveFactor > 0.43) {
              const randType = Math.random();
              let bType: 'stone' | 'iron' | 'gold' = 'stone';
              let maxHp = 140;

              if (randType < 0.05) {
                bType = 'gold'; // gold ore
                maxHp = 260;
              } else if (randType < 0.14) {
                bType = 'iron';
                maxHp = 180;
              }

              chunkResources.push({
                id: tId,
                type: bType,
                x: tileX,
                y: tileY,
                width: TILE_SIZE,
                height: TILE_SIZE,
                health: maxHp,
                maxHealth: maxHp,
                respawnTime: null,
              });
            } else {
              // Open cavern pathways can spawn Lava pockets!
              const lavaFactor = this.noise.noise2D(globX * 0.22, globY * 0.22);
              if (lavaFactor > 0.85) {
                lava.push({
                  x: tileX - TILE_SIZE / 2,
                  y: tileY - TILE_SIZE / 2,
                  width: TILE_SIZE,
                  height: TILE_SIZE,
                });
              }
            }

            // Up/Down Portals
            if (gx === 5 && gy === 5 && cx % 2 === 1 && cy % 2 === 1) {
              chunkResources.push({
                id: `portal_up_${cx}_${cy}`,
                type: 'stairs-up',
                x: tileX,
                y: tileY,
                width: 60,
                height: 60,
                health: 99999,
                maxHealth: 99999,
                respawnTime: null,
              });
            }
            if (gx === 11 && gy === 11 && cx % 2 === 1 && cy % 2 === 1) {
              chunkResources.push({
                id: `portal_down_${cx}_${cy}`,
                type: 'stairs-down',
                x: tileX,
                y: tileY,
                width: 60,
                height: 60,
                health: 99999,
                maxHealth: 99999,
                respawnTime: null,
              });
            }
            break;
          }

          case 'underworld': {
            // Hellish underworld volcanic region
            bgWalls.push({ x: tileX, y: tileY, type: 'obsidian' });

            const caveFactor = this.noise.fbm2D(globX * 0.12, globY * 0.12, 3);
            if (caveFactor > 0.54) {
              // Solid obsidian ashes
              const randType = Math.random();
              let bType: 'stone' | 'hellstone' = 'stone';
              let maxHp = 180;

              if (randType < 0.15) {
                bType = 'hellstone'; // precious underworld Hellstone
                maxHp = 350;
              }

              chunkResources.push({
                id: tId,
                type: bType,
                x: tileX,
                y: tileY,
                width: TILE_SIZE,
                height: TILE_SIZE,
                health: maxHp,
                maxHealth: maxHp,
                respawnTime: null,
              });
            } else {
              // Rivers of molten hellfire lava of underworld death
              const lavaFactor = this.noise.noise2D(globX * 0.16, globY * 0.16);
              if (lavaFactor > 0.4) {
                lava.push({
                  x: tileX - TILE_SIZE / 2,
                  y: tileY - TILE_SIZE / 2,
                  width: TILE_SIZE,
                  height: TILE_SIZE,
                });
              }
            }

            // Escape stairs back up
            if (gx === 8 && gy === 8 && cx % 2 === 0) {
              chunkResources.push({
                id: `portal_up_${cx}_${cy}`,
                type: 'stairs-up',
                x: tileX,
                y: tileY,
                width: 60,
                height: 60,
                health: 99999,
                maxHealth: 99999,
                respawnTime: null,
              });
            }
            break;
          }
        }
      }
    }

    // --- PROCEDURAL NATURALLY-GENERATED STRUCTURES SYSTEM (TERRARIA-LIKE) ---
    const chunkWalls: ProtectiveWall[] = [];
    const chunkEnemies: Enemy[] = [];

    // Skip spawn point safe starter zone
    const isCoreChunk = Math.abs(cx) <= 1 && Math.abs(cy) <= 1;
    const structureHash = this.noise.hash2D(cx + 91.43, cy - 47.61);

    if (!isCoreChunk && structureHash < 0.09) {
      const distFromOrigin = Math.hypot(cx, cy);
      const difficultyScale = 1.0 + distFromOrigin * 0.12;

      // Clean up existing resources in the central 9x9 grid zone of the chunk to prevent clipping
      const isCentralTile = (gx: number, gy: number) => gx >= 4 && gx <= 11 && gy >= 4 && gy <= 11;
      const initialResources = [...chunkResources];
      chunkResources.length = 0;
      initialResources.forEach((res) => {
        // Derive local grid coordinates of resource node
        const lgx = Math.floor((res.x - startX) / TILE_SIZE);
        const lgy = Math.floor((res.y - startY) / TILE_SIZE);
        if (!isCentralTile(lgx, lgy)) {
          chunkResources.push(res);
        }
      });

      // Choose structure type based on structural index dynamically (7 unique structures)
      const structTypeIndex = Math.floor(structureHash * 100) % 7;
      const wallMaterial = (biome === 'desert' || biome === 'swamp' || biome === 'mountains') ? 'stone' : 'wood';
      const defaultWallHp = wallMaterial === 'wood' ? 180 : 420;
      const wallHp = Math.round(defaultWallHp * difficultyScale);

      // Structure 1: CABINS (Case 0)
      if (structTypeIndex === 0) {
        // Build walls of Cabin (6x5 room, from gx=5 to 10, gy=5 to 9)
        for (let gy = 5; gy <= 9; gy++) {
          for (let gx = 5; gx <= 10; gx++) {
            const rx = startX + gx * TILE_SIZE;
            const ry = startY + gy * TILE_SIZE;
            const isBoundary = gx === 5 || gx === 10 || gy === 5 || gy === 9;
            const isDoorway = gx === 7 && gy === 9; // entry gate at bottom center
            if (isBoundary) {
              if (isDoorway) {
                chunkWalls.push({
                  id: `cabin_door_${cx}_${cy}`,
                  type: 'wooden-gate',
                  gridX: cx * CHUNK_TILES + gx,
                  gridY: cy * CHUNK_TILES + gy,
                  x: rx,
                  y: ry,
                  width: TILE_SIZE,
                  height: TILE_SIZE,
                  health: 150,
                  maxHealth: 150,
                  isOpen: false,
                });
              } else {
                chunkWalls.push({
                  id: `cabin_wall_${cx}_${cy}_${gx}_${gy}`,
                  type: wallMaterial,
                  gridX: cx * CHUNK_TILES + gx,
                  gridY: cy * CHUNK_TILES + gy,
                  x: rx,
                  y: ry,
                  width: TILE_SIZE,
                  height: TILE_SIZE,
                  health: wallHp,
                  maxHealth: wallHp,
                });
              }
            }
          }
        }
        // Hearth fireplace inside
        chunkWalls.push({
          id: `cabin_torch_${cx}_${cy}`,
          type: 'torch',
          gridX: cx * CHUNK_TILES + 6,
          gridY: cy * CHUNK_TILES + 6,
          x: startX + 6 * TILE_SIZE,
          y: startY + 6 * TILE_SIZE,
          width: TILE_SIZE,
          height: TILE_SIZE,
          health: 50,
          maxHealth: 50,
        });
        // Chest inside
        chunkResources.push({
          id: `cabin_chest_${cx}_${cy}`,
          type: layer === 'underworld' ? 'hellstone-chest' : layer === 'sky' ? 'sky-chest' : 'chest',
          x: startX + 8 * TILE_SIZE + TILE_SIZE/2,
          y: startY + 7 * TILE_SIZE + TILE_SIZE/2,
          width: 50,
          height: 50,
          health: 1,
          maxHealth: 1,
          respawnTime: null,
        });
        // Cabin guard zombie
        chunkEnemies.push({
          id: `cabin_guard_${cx}_${cy}_1`,
          type: 'zombie',
          x: startX + 8 * TILE_SIZE,
          y: startY + 7 * TILE_SIZE + 40,
          radius: 15,
          width: 30,
          height: 45,
          health: Math.round(45 * difficultyScale),
          maxHealth: Math.round(45 * difficultyScale),
          speed: 1.6,
          damage: Math.round(11 * difficultyScale),
          angle: 0,
          flashRedTime: 0,
          creeperExplodeTime: null,
          targetWallId: null,
          lastAttackTime: 0,
        });

      // Structure 2: RUINS (Case 1)
      } else if (structTypeIndex === 1) {
        // Collapsed stone structures with procedural decay holes
        for (let gy = 4; gy <= 9; gy++) {
          for (let gx = 4; gx <= 11; gx++) {
            const rx = startX + gx * TILE_SIZE;
            const ry = startY + gy * TILE_SIZE;
            const isBoundary = gx === 4 || gx === 11 || gy === 4 || gy === 9;
            const decayHash = this.noise.hash2D(cx + gx, cy + gy);
            if (isBoundary && decayHash < 0.65) {
              chunkWalls.push({
                id: `ruin_wall_${cx}_${cy}_${gx}_${gy}`,
                type: 'stone',
                gridX: cx * CHUNK_TILES + gx,
                gridY: cy * CHUNK_TILES + gy,
                x: rx,
                y: ry,
                width: TILE_SIZE,
                height: TILE_SIZE,
                health: Math.round(280 * difficultyScale),
                maxHealth: Math.round(280 * difficultyScale),
              });
            }
          }
        }
        // Hidden Chest among ruins
        chunkResources.push({
          id: `ruin_chest_${cx}_${cy}`,
          type: layer === 'underworld' ? 'hellstone-chest' : layer === 'sky' ? 'sky-chest' : 'chest',
          x: startX + 7 * TILE_SIZE + TILE_SIZE/2,
          y: startY + 6 * TILE_SIZE + TILE_SIZE/2,
          width: 50,
          height: 50,
          health: 1,
          maxHealth: 1,
          respawnTime: null,
        });
        // Ruins skeleton guard
        chunkEnemies.push({
          id: `ruin_guard_${cx}_${cy}`,
          type: 'skeleton',
          x: startX + 7 * TILE_SIZE,
          y: startY + 6 * TILE_SIZE - 20,
          radius: 14,
          width: 28,
          height: 42,
          health: Math.round(50 * difficultyScale),
          maxHealth: Math.round(50 * difficultyScale),
          speed: 1.8,
          damage: Math.round(14 * difficultyScale),
          angle: 0,
          flashRedTime: 0,
          creeperExplodeTime: null,
          targetWallId: null,
          lastAttackTime: 0,
        });

      // Structure 3: TOWERS (Case 2)
      } else if (structTypeIndex === 2) {
        // High strategic brick tower
        for (let gy = 4; gy <= 10; gy++) {
          for (let gx = 5; gx <= 9; gx++) {
            const rx = startX + gx * TILE_SIZE;
            const ry = startY + gy * TILE_SIZE;
            const isBoundary = gx === 5 || gx === 9 || gy === 4 || gy === 10;
            const isDoor = gx === 7 && gy === 10;
            if (isBoundary) {
              if (isDoor) {
                chunkWalls.push({
                  id: `tower_gate_${cx}_${cy}`,
                  type: 'wooden-gate',
                  gridX: cx * CHUNK_TILES + gx,
                  gridY: cy * CHUNK_TILES + gy,
                  x: rx,
                  y: ry,
                  width: TILE_SIZE,
                  height: TILE_SIZE,
                  health: 180,
                  maxHealth: 180,
                  isOpen: false,
                });
              } else {
                chunkWalls.push({
                  id: `tower_wall_${cx}_${cy}_${gx}_${gy}`,
                  type: 'stone',
                  gridX: cx * CHUNK_TILES + gx,
                  gridY: cy * CHUNK_TILES + gy,
                  x: rx,
                  y: ry,
                  width: TILE_SIZE,
                  height: TILE_SIZE,
                  health: Math.round(500 * difficultyScale),
                  maxHealth: Math.round(500 * difficultyScale),
                });
              }
            }
          }
        }
        // Active tower wall torch
        chunkWalls.push({
          id: `tower_wall_torch_${cx}_${cy}`,
          type: 'torch',
          gridX: cx * CHUNK_TILES + 6,
          gridY: cy * CHUNK_TILES + 5,
          x: startX + 6 * TILE_SIZE,
          y: startY + 5 * TILE_SIZE,
          width: TILE_SIZE,
          height: TILE_SIZE,
          health: 50,
          maxHealth: 50,
        });
        // Tower dungeon chest
        chunkResources.push({
          id: `tower_chest_${cx}_${cy}`,
          type: 'chest',
          x: startX + 7 * TILE_SIZE + TILE_SIZE/2,
          y: startY + 6 * TILE_SIZE + TILE_SIZE/2,
          width: 50,
          height: 50,
          health: 1,
          maxHealth: 1,
          respawnTime: null,
        });

      // Structure 4: DUNGEONS (Case 3)
      } else if (structTypeIndex === 3) {
        // Deep mossy stone slab tombs
        for (let gy = 4; gy <= 10; gy++) {
          for (let gx = 4; gx <= 11; gx++) {
            const rx = startX + gx * TILE_SIZE;
            const ry = startY + gy * TILE_SIZE;
            const isBoundary = gx === 4 || gx === 11 || gy === 4 || gy === 10;
            const isEntry = gx === 7 && gy === 10;
            if (isBoundary && !isEntry) {
              chunkWalls.push({
                id: `dungeon_wall_${cx}_${cy}_${gx}_${gy}`,
                type: 'stone',
                gridX: cx * CHUNK_TILES + gx,
                gridY: cy * CHUNK_TILES + gy,
                x: rx,
                y: ry,
                width: TILE_SIZE,
                height: TILE_SIZE,
                health: Math.round(600 * difficultyScale),
                maxHealth: Math.round(600 * difficultyScale),
              });
            }
          }
        }
        // Spike trap protections at dungeon entrance
        chunkWalls.push({
          id: `dungeon_spike_${cx}_${cy}_1`,
          type: 'spike-trap',
          gridX: cx * CHUNK_TILES + 6,
          gridY: cy * CHUNK_TILES + 8,
          x: startX + 6 * TILE_SIZE,
          y: startY + 8 * TILE_SIZE,
          width: TILE_SIZE,
          height: TILE_SIZE,
          health: 120,
          maxHealth: 120,
        });
        chunkWalls.push({
          id: `dungeon_spike_${cx}_${cy}_2`,
          type: 'spike-trap',
          gridX: cx * CHUNK_TILES + 8,
          gridY: cy * CHUNK_TILES + 8,
          x: startX + 8 * TILE_SIZE,
          y: startY + 8 * TILE_SIZE,
          width: TILE_SIZE,
          height: TILE_SIZE,
          health: 120,
          maxHealth: 120,
        });
        // Ancient Dungeon Chest (Loot chest)
        chunkResources.push({
          id: `dungeon_chest_${cx}_${cy}`,
          type: layer === 'underworld' ? 'hellstone-chest' : 'chest',
          x: startX + 7 * TILE_SIZE + TILE_SIZE/2,
          y: startY + 6 * TILE_SIZE + TILE_SIZE/2,
          width: 50,
          height: 50,
          health: 1,
          maxHealth: 1,
          respawnTime: null,
        });
        // Skeleton guards
        chunkEnemies.push({
          id: `dungeon_skele_${cx}_${cy}`,
          type: 'skeleton',
          x: startX + 7 * TILE_SIZE,
          y: startY + 5 * TILE_SIZE,
          radius: 14,
          width: 28,
          height: 42,
          health: Math.round(60 * difficultyScale),
          maxHealth: Math.round(60 * difficultyScale),
          speed: 1.8,
          damage: Math.round(15 * difficultyScale),
          angle: 0,
          flashRedTime: 0,
          creeperExplodeTime: null,
          targetWallId: null,
          lastAttackTime: 0,
        });

      // Structure 5: OUTPOSTS (Case 4)
      } else if (structTypeIndex === 4) {
        // Wooden/stone hybrid frontier outpost with defenses
        for (let gy = 5; gy <= 9; gy++) {
          for (let gx = 5; gx <= 10; gx++) {
            const rx = startX + gx * TILE_SIZE;
            const ry = startY + gy * TILE_SIZE;
            const isBoundary = gx === 5 || gx === 10 || gy === 5 || gy === 9;
            const isOpening = gx === 10 && gy === 7;
            if (isBoundary && !isOpening) {
              chunkWalls.push({
                id: `outpost_wall_${cx}_${cy}_${gx}_${gy}`,
                type: wallMaterial,
                gridX: cx * CHUNK_TILES + gx,
                gridY: cy * CHUNK_TILES + gy,
                x: rx,
                y: ry,
                width: TILE_SIZE,
                height: TILE_SIZE,
                health: wallHp,
                maxHealth: wallHp,
              });
            }
          }
        }
        // Defending spikes near entrance door
        chunkWalls.push({
          id: `outpost_spike_${cx}_${cy}`,
          type: 'spike-trap',
          gridX: cx * CHUNK_TILES + 10,
          gridY: cy * CHUNK_TILES + 8,
          x: startX + 10 * TILE_SIZE,
          y: startY + 8 * TILE_SIZE,
          width: TILE_SIZE,
          height: TILE_SIZE,
          health: 120,
          maxHealth: 120,
        });
        // Chest
        chunkResources.push({
          id: `outpost_chest_${cx}_${cy}`,
          type: 'chest',
          x: startX + 7 * TILE_SIZE + TILE_SIZE/2,
          y: startY + 7 * TILE_SIZE + TILE_SIZE/2,
          width: 50,
          height: 50,
          health: 1,
          maxHealth: 1,
          respawnTime: null,
        });
        // Skeleton shooter
        chunkEnemies.push({
          id: `outpost_guard_${cx}_${cy}`,
          type: 'skeleton',
          x: startX + 7 * TILE_SIZE,
          y: startY + 6 * TILE_SIZE,
          radius: 14,
          width: 28,
          height: 42,
          health: Math.round(50 * difficultyScale),
          maxHealth: Math.round(50 * difficultyScale),
          speed: 1.7,
          damage: Math.round(13 * difficultyScale),
          angle: 0,
          flashRedTime: 0,
          creeperExplodeTime: null,
          targetWallId: null,
          lastAttackTime: 0,
        });

      // Structure 6: CAMPS (Case 5)
      } else if (structTypeIndex === 5) {
        // Active camp fire with survival logs
        chunkWalls.push({
          id: `camp_fire_${cx}_${cy}`,
          type: 'torch',
          gridX: cx * CHUNK_TILES + 8,
          gridY: cy * CHUNK_TILES + 8,
          x: startX + 8 * TILE_SIZE,
          y: startY + 8 * TILE_SIZE,
          width: TILE_SIZE,
          height: TILE_SIZE,
          health: 120,
          maxHealth: 120,
        });
        // Firewood logs directly mineable for quick mats!
        chunkResources.push({
          id: `camp_log_bundle_${cx}_${cy}_1`,
          type: 'wood',
          x: startX + 6 * TILE_SIZE + TILE_SIZE/2,
          y: startY + 8 * TILE_SIZE + TILE_SIZE/2,
          width: 48,
          height: 48,
          health: 40,
          maxHealth: 40,
          respawnTime: null,
        });
        chunkResources.push({
          id: `camp_log_bundle_${cx}_${cy}_2`,
          type: 'wood',
          x: startX + 9 * TILE_SIZE + TILE_SIZE/2,
          y: startY + 8 * TILE_SIZE + TILE_SIZE/2,
          width: 48,
          height: 48,
          health: 40,
          maxHealth: 40,
          respawnTime: null,
        });
        // Supplies Chest
        chunkResources.push({
          id: `camp_chest_${cx}_${cy}`,
          type: 'chest',
          x: startX + 8 * TILE_SIZE + TILE_SIZE/2,
          y: startY + 6 * TILE_SIZE + TILE_SIZE/2,
          width: 50,
          height: 50,
          health: 1,
          maxHealth: 1,
          respawnTime: null,
        });
        // Hostile camper protecting camp
        chunkEnemies.push({
          id: `camp_occupant_${cx}_${cy}`,
          type: 'zombie',
          x: startX + 8 * TILE_SIZE,
          y: startY + 7 * TILE_SIZE,
          radius: 15,
          width: 30,
          height: 45,
          health: Math.round(42 * difficultyScale),
          maxHealth: Math.round(42 * difficultyScale),
          speed: 1.5,
          damage: Math.round(10 * difficultyScale),
          angle: 0,
          flashRedTime: 0,
          creeperExplodeTime: null,
          targetWallId: null,
          lastAttackTime: 0,
        });

      // Structure 7: SHRINES (Case 6)
      } else if (structTypeIndex === 6) {
        // Celestial columns block circle
        for (let j = 0; j < 4; j++) {
          const gx = j === 0 || j === 1 ? 5 : 10;
          const gy = j === 0 || j === 2 ? 5 : 9;
          // Gold resource pillars!
          chunkResources.push({
            id: `shrine_pillar_${cx}_${cy}_${j}`,
            type: 'gold' as any,
            x: startX + gx * TILE_SIZE + TILE_SIZE/2,
            y: startY + gy * TILE_SIZE + TILE_SIZE/2,
            width: TILE_SIZE,
            height: TILE_SIZE,
            health: Math.round(150 * difficultyScale),
            maxHealth: Math.round(150 * difficultyScale),
            respawnTime: null,
          });
        }
        chunkWalls.push({
          id: `shrine_flame_${cx}_${cy}`,
          type: 'torch',
          gridX: cx * CHUNK_TILES + 7,
          gridY: cy * CHUNK_TILES + 5,
          x: startX + 7 * TILE_SIZE,
          y: startY + 5 * TILE_SIZE,
          width: TILE_SIZE,
          height: TILE_SIZE,
          health: 50,
          maxHealth: 50,
        });
        // High quality Shrine chest in the center of the columns
        chunkResources.push({
          id: `shrine_chest_${cx}_${cy}`,
          type: layer === 'sky' ? 'sky-chest' : layer === 'underworld' ? 'hellstone-chest' : 'chest',
          x: startX + 7 * TILE_SIZE + TILE_SIZE/2,
          y: startY + 7 * TILE_SIZE + TILE_SIZE/2,
          width: 50,
          height: 50,
          health: 1,
          maxHealth: 1,
          respawnTime: null,
        });
        // High difficulty creeper relic-guardian
        chunkEnemies.push({
          id: `shrine_creeper_${cx}_${cy}`,
          type: 'creeper',
          x: startX + 8 * TILE_SIZE,
          y: startY + 7 * TILE_SIZE,
          radius: 13,
          width: 26,
          height: 39,
          health: Math.round(30 * difficultyScale),
          maxHealth: Math.round(30 * difficultyScale),
          speed: 2.2,
          damage: Math.round(35 * difficultyScale),
          angle: 0,
          flashRedTime: 0,
          creeperExplodeTime: null,
          targetWallId: null,
          lastAttackTime: 0,
        });
      }
    }

    return {
      cx,
      cy,
      layer,
      biome,
      resources: chunkResources,
      backgroundWalls: bgWalls,
      lavaPools: lava,
      walls: chunkWalls,
      enemies: chunkEnemies,
      hasGenerated: true,
    };
  }
}
export const worldGenerator = new WorldGenerator();
