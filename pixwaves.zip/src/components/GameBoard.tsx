import { useEffect, useRef, useState, useTransition } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Shield,
  Hammer,
  Sparkles,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
  Plus,
  Compass,
  Zap,
  Target,
  Flame,
  Wrench,
  Trophy,
  BookOpen,
} from 'lucide-react';
import { audio } from '../utils/audio';
import { worldGenerator } from '../utils/worldGenerator';
import {
  Position,
  ResourceNode,
  Enemy,
  ProtectiveWall,
  Turret,
  Projectile,
  XPGem,
  Particle,
  BotPlayer,
  UpgradeOption,
  HotbarItem,
  WallType
} from '../types';

// Constants
const TILE_SIZE = 60;
const MAP_WIDTH = 3000;
const MAP_HEIGHT = 3000;
const PLACEMENT_RANGE = 250;

// Leaderboard names (random simulated player bots)
const BOT_NAMES = ['Herobrine', 'StevePro', 'AlexIO', 'MineLord', 'GridGod', 'NoobBooster', 'TurretKing', 'BlockMaster', 'DiamondHype', 'SlayerXD'];

// Multi-category multi-variant hotbar definition
const CUSTOM_HOTBAR = [
  // Slot 1: Melee Weapons
  [
    { slot: 1, name: 'Steel Dagger', type: 'weapon', targetType: 'dagger', costWood: 0, costStone: 0, costIron: 0, description: 'Extremely fast close-range stabs' },
    { slot: 1, name: 'Steel Broadsword', type: 'weapon', targetType: 'sword', costWood: 0, costStone: 0, costIron: 0, description: 'Balanced high-durability blade' },
    { slot: 1, name: 'Logger Axe', type: 'weapon', targetType: 'axe', costWood: 0, costStone: 0, costIron: 0, description: 'Chops woods quickly and chops skulls' },
    { slot: 1, name: 'Kings Greatsword', type: 'weapon', targetType: 'greatsword', costWood: 0, costStone: 0, costIron: 0, description: 'Massive sweeps with heavy knockback' },
    { slot: 1, name: 'Spike Spear', type: 'weapon', targetType: 'spear', costWood: 0, costStone: 0, costIron: 0, description: 'Long straight piercing thrust attack' }
  ],
  // Slot 2: Ranged Weapons & Shields
  [
    { slot: 2, name: 'Composite Bow', type: 'weapon', targetType: 'bow', costWood: 0, costStone: 0, costIron: 0, description: 'Standard high-speed arrows' },
    { slot: 2, name: 'Heavy Crossbow', type: 'weapon', targetType: 'crossbow', costWood: 0, costStone: 0, costIron: 0, description: 'High-damage piercing bolts (slower reload)' },
    { slot: 2, name: 'Wooden Shield', type: 'shield', targetType: 'wood-shield', costWood: 0, costStone: 0, costIron: 0, description: 'Blocks 100% incoming frontal hits' },
    { slot: 2, name: 'Spiked Iron Shield', type: 'shield', targetType: 'iron-shield', costWood: 0, costStone: 0, costIron: 0, description: 'Blocks front damage & thorns hit enemies' }
  ],
  // Slot 3: Protective Fortifications
  [
    { slot: 3, name: 'Wooden Wall', type: 'wall', targetType: 'wood', costWood: 6, costStone: 0, costIron: 0, description: 'Affordable pine wall blockade' },
    { slot: 3, name: 'Stone Wall', type: 'wall', targetType: 'stone', costWood: 0, costStone: 10, costIron: 0, description: 'Sturdier stone wall fortifications' },
    { slot: 3, name: 'Wooden Gate', type: 'wall', targetType: 'wooden-gate', costWood: 15, costStone: 0, costIron: 4, description: 'Blocks enemies when shut. Left-click to open/close' }
  ],
  // Slot 4: Combat Turrets & Spike traps
  [
    { slot: 4, name: 'Wooden Turret', type: 'turret', targetType: 'wooden-turret', costWood: 20, costStone: 5, costIron: 0, description: 'Fires poison darts at enemies' },
    { slot: 4, name: 'Stone Turret', type: 'turret', targetType: 'stone-turret', costWood: 10, costStone: 25, costIron: 5, description: 'Fires heavy stone bullets' },
    { slot: 4, name: 'Fire Turret', type: 'turret', targetType: 'fire-turret', costWood: 15, costStone: 15, costIron: 12, description: 'Launches explosive fireballs!' },
    { slot: 4, name: 'Arrow Turret', type: 'turret', targetType: 'arrow-turret', costWood: 25, costStone: 10, costIron: 2, description: 'Automatic long-range arrows' },
    { slot: 4, name: 'Wall Turret', type: 'turret', targetType: 'wall-turret', costWood: 12, costStone: 12, costIron: 8, description: 'High-fire rate turret (attaches best to defenses)' },
    { slot: 4, name: 'Spike Trap', type: 'wall', targetType: 'spike-trap', costWood: 0, costStone: 10, costIron: 2, description: 'Deals automatic passive physical puncture damage' }
  ],
  // Slot 5: Mining tools & Utilities
  [
    { slot: 5, name: 'Steel Pickaxe', type: 'tool', targetType: 'pickaxe', costWood: 0, costStone: 0, costIron: 0, description: 'Fast harvest tool for stone and ore nodes' },
    { slot: 5, name: 'Glowing Torch', type: 'wall', targetType: 'torch', costWood: 3, costStone: 0, costIron: 0, description: 'Ground sconce that lights up cave dark spots' }
  ]
];

export default function GameBoard() {
  const [, startTransition] = useTransition();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Core Game status
  const [gameState, setGameState] = useState<'START' | 'PLAYING' | 'UPGRADE_SELECT' | 'GAME_OVER'>('START');
  const [isMuted, setIsMuted] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    try {
      return parseInt(localStorage.getItem('block_survival_highscore') || '0', 10);
    } catch {
      return 0;
    }
  });

  // Client display stats (synchronized from loop for REACT HUD overlay)
  const [hudStats, setHudStats] = useState({
    health: 100,
    maxHealth: 100,
    wood: 25,
    stone: 15,
    iron: 0,
    wave: 1,
    enemiesRemaining: 0,
    timeToNextWave: 120, // Countdown timer in seconds
    isWaveActive: false,
    level: 1,
    xp: 0,
    xpNeeded: 120,
    activeSlot: 1,
  });

  // Leaderboard data state
  const [leaderboard, setLeaderboard] = useState<BotPlayer[]>([]);

  // Upgrade picks
  const [upgradeChoices, setUpgradeChoices] = useState<UpgradeOption[]>([]);

  // Show place bounds warning overlay
  const [placementError, setPlacementError] = useState<string | null>(null);

  // Game references used inside the requestAnimationFrame loop to avoid react state bottlenecks
  const gRef = useRef({
    player: {
      x: MAP_WIDTH / 2,
      y: MAP_HEIGHT / 2,
      vx: 0,
      vy: 0,
      radius: 17,
      speed: 5.5,
      health: 100,
      maxHealth: 100,
      wood: 35,
      stone: 20,
      iron: 2,
      level: 1,
      xp: 0,
      xpNeeded: 120,
      miningPower: 15, // Damage dealt to resource nodes
      arrowDamage: 25,
      arrowReloadTime: 400, // miliseconds between shots
      lastShotTime: 0,
      turretRateMultiplier: 1.0,
      regenTimer: 0,
      regenAmount: 0, // Health healed per 3 seconds
      angle: 0,
      portalCooldown: 0, // immunity frames between dimensional transfers
    },
    // Dynamic Procedural Chunk Persistence Engine
    depthLayer: 'surface' as 'sky' | 'surface' | 'underground' | 'cavern' | 'underworld',
    loadedChunks: {
      sky: {} as Record<string, any>,
      surface: {} as Record<string, any>,
      underground: {} as Record<string, any>,
      cavern: {} as Record<string, any>,
      underworld: {} as Record<string, any>,
    },
    activeChunks: [] as string[],
    backgroundWalls: [] as { x: number; y: number; type: 'dirt' | 'stone' | 'obsidian' | 'cloud' }[],
    lavaPools: [] as { x: number; y: number; width: number; height: number }[],
    lastChunkX: null as number | null,
    lastChunkY: null as number | null,

    // Map objects
    resources: [] as ResourceNode[],
    walls: [] as ProtectiveWall[],
    turrets: [] as Turret[],
    enemies: [] as Enemy[],
    projectiles: [] as Projectile[],
    projectilePool: Array.from({ length: 150 }, (_, idx) => ({
      id: `proj_${idx}`,
      type: 'arrow',
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      radius: 0,
      damage: 0,
      life: 0,
      maxLife: 0,
      isMeleeAttack: false,
      pierceCount: 1,
    })),
    nextProjectileIndex: 0,
    xpGems: [] as XPGem[],
    particles: [] as Particle[],
    particlePool: Array.from({ length: 500 }, (_, idx) => ({
      id: `p_${idx}`,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      size: 0,
      color: '#fff',
      life: 0,
      maxLife: 0,
      isGravity: false,
      z: 0,
      vz: 0,
    })),
    nextParticleIndex: 0,
    
    // Wave systems
    wave: 1,
    enemiesToSpawn: 0,
    enemiesSpawned: 0,
    waveTimer: 120 * 60, // frames until wave start (2 minutes at 60fps)
    isWaveActive: false,
    waveCheckCooldown: 0,
    waveTransitionTimer: 0,

    // Controls
    keys: {} as Record<string, boolean>,
    mouse: { x: 0, y: 0, worldX: 0, worldY: 0, isDown: false },
    activeSlot: 1,
    hotbarSubIndices: [0, 0, 0, 0, 0] as number[],
    meleeSwingAngle: null as number | null,
    meleeSwingProgress: 0,
    meleeHitRegister: new Set<string>(),
    hitstopFrames: 0,

    // Leaderboard
    bots: [] as BotPlayer[],
    lastBotUpdate: 0,
  });

  // Hotbar active index
  const [activeSlot, setActiveSlot] = useState(1);
  const [hotbarSubIndices, setHotbarSubIndices] = useState<number[]>([0, 0, 0, 0, 0]);

  // Clear or reset hotbar state
  const changeActiveSlot = (slot: number) => {
    setActiveSlot(slot);
    gRef.current.activeSlot = slot;
  };

  // Keyboard and wheel listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent scrolling with arrows/spacebar
      if (['ArrowUp', 'ArrowDown', 'Space', ' '].includes(e.key)) {
        e.preventDefault();
      }
      gRef.current.keys[e.key.toLowerCase()] = true;

      // Slot keys 1-5
      const num = parseInt(e.key, 10);
      if (num >= 1 && num <= 5) {
        if (gRef.current.activeSlot === num) {
          const maxVariants = CUSTOM_HOTBAR[num - 1].length;
          const nextIdx = (gRef.current.hotbarSubIndices[num - 1] + 1) % maxVariants;
          gRef.current.hotbarSubIndices[num - 1] = nextIdx;
          setHotbarSubIndices([...gRef.current.hotbarSubIndices]);
          audio.playPlace();
        } else {
          changeActiveSlot(num);
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      gRef.current.keys[e.key.toLowerCase()] = false;
    };

    const handleWheel = (e: WheelEvent) => {
      let current = gRef.current.activeSlot;
      if (e.deltaY > 0) {
        current = current === 5 ? 1 : current + 1;
      } else {
        current = current === 1 ? 5 : current - 1;
      }
      changeActiveSlot(current);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('wheel', handleWheel, { passive: true });

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('wheel', handleWheel);
    };
  }, []);

  // Initialize Leaderboard & Bots
  const initLeaderboard = () => {
    const list: BotPlayer[] = BOT_NAMES.map((name, i) => ({
      id: `bot_${i}`,
      name,
      score: Math.floor(Math.random() * 500) + 100,
      kills: Math.floor(Math.random() * 5),
    }));
    gRef.current.bots = list;
    // Set initially
    setLeaderboard([...list, { id: 'player_id', name: 'You', score: 0, kills: 0, isPlayer: true }].sort((a,b) => b.score - a.score));
  };

  // Trigger mute toggle
  const toggleMute = () => {
    const muted = audio.toggleMute();
    setIsMuted(muted);
  };

  // Handle Game Start
  const triggerStartGame = () => {
    audio.playPlace(); // Test context trigger
    setScore(0);
    initLeaderboard();
    
    // Setup initial structures
    const gr = gRef.current;
    
    // Reset Dynamic Chunk Persistence Engine
    gr.depthLayer = 'surface';
    gr.loadedChunks = {
      sky: {},
      surface: {},
      underground: {},
      cavern: {},
      underworld: {},
    };
    gr.activeChunks = [];
    gr.backgroundWalls = [];
    gr.lavaPools = [];
    gr.lastChunkX = null;
    gr.lastChunkY = null;

    gr.player = {
      x: MAP_WIDTH / 2,
      y: MAP_HEIGHT / 2,
      vx: 0,
      vy: 0,
      radius: 17,
      speed: 5.5,
      health: 100,
      maxHealth: 100,
      wood: 40,
      stone: 20,
      iron: 2,
      level: 1,
      xp: 0,
      xpNeeded: 120,
      miningPower: 15,
      arrowDamage: 25,
      arrowReloadTime: 400,
      lastShotTime: 0,
      turretRateMultiplier: 1.0,
      regenTimer: 0,
      regenAmount: 0,
      angle: 0,
      portalCooldown: 0,
    };

    gr.resources = [];
    gr.walls = [];
    gr.turrets = [];
    gr.enemies = [];
    gr.projectiles = [];
    gr.xpGems = [];
    gr.particles = [];
    gr.wave = 1;
    gr.isWaveActive = false;
    gr.waveTimer = 120 * 60; // 2 minutes (120 seconds) of safety setup
    gr.waveTransitionTimer = 0;

    // Load initial 5x5 chunk grid surrounding player
    reconcileChunks(true);

    // Trigger State
    setGameState('PLAYING');
    
    setHudStats({
      health: 100,
      maxHealth: 100,
      wood: 40,
      stone: 20,
      iron: 2,
      wave: 1,
      enemiesRemaining: 0,
      timeToNextWave: 120,
      isWaveActive: false,
      level: 1,
      xp: 0,
      xpNeeded: 120,
      activeSlot: 1,
    });
  };

  const saveCurrentActiveChunksToMemory = () => {
    const gr = gRef.current;
    const layer = gr.depthLayer;
    const CHUNK_SIZE_PX = 16 * TILE_SIZE; // 960px

    gr.activeChunks.forEach((chunkKey) => {
      const parts = chunkKey.split(',');
      const cx = parseInt(parts[0], 10);
      const cy = parseInt(parts[1], 10);

      const startX = cx * CHUNK_SIZE_PX;
      const endX = startX + CHUNK_SIZE_PX;
      const startY = cy * CHUNK_SIZE_PX;
      const endY = startY + CHUNK_SIZE_PX;

      // Extract parts falling within chunk coordinates
      const chunkResources = gr.resources.filter(
        (node) => node.x >= startX && node.x < endX && node.y >= startY && node.y < endY
      );
      const chunkWalls = gr.walls.filter(
        (wall) => wall.x >= startX && wall.x < endX && wall.y >= startY && wall.y < endY
      );
      const chunkTurrets = gr.turrets.filter(
        (turret) => turret.x >= startX && turret.x < endX && turret.y >= startY && turret.y < endY
      );

      if (!gr.loadedChunks[layer]) {
         gr.loadedChunks[layer] = {};
      }

      const chunk = gr.loadedChunks[layer][chunkKey];
      if (chunk) {
        chunk.resources = chunkResources;
        // Optionally store walls and turrets
        chunk.walls = chunkWalls;
        chunk.turrets = chunkTurrets;
      }
    });
  };

  const reconcileChunks = (force = false) => {
    const gr = gRef.current;
    const layer = gr.depthLayer;
    const CHUNK_SIZE_PX = 16 * TILE_SIZE; // 960px

    const playerChunkX = Math.floor(gr.player.x / CHUNK_SIZE_PX);
    const playerChunkY = Math.floor(gr.player.y / CHUNK_SIZE_PX);

    if (
      gr.lastChunkX === playerChunkX &&
      gr.lastChunkY === playerChunkY &&
      !force
    ) {
      return; // same chunk coordinates, return early
    }

    gr.lastChunkX = playerChunkX;
    gr.lastChunkY = playerChunkY;

    // Tight chunk generation radius around the player, unload 5 chunks away
    const activeRadius = 3;
    const unloadRadius = 5;
    
    const newActiveKeysSet = new Set<string>();
    const keepKeysSet = new Set<string>();

    for (let dy = -activeRadius; dy <= activeRadius; dy++) {
      for (let dx = -activeRadius; dx <= activeRadius; dx++) {
        const cx = playerChunkX + dx;
        const cy = playerChunkY + dy;
        newActiveKeysSet.add(`${cx},${cy}`);
      }
    }

    // Keep anything closer than 12 chunks
    for (let dy = -unloadRadius; dy <= unloadRadius; dy++) {
      for (let dx = -unloadRadius; dx <= unloadRadius; dx++) {
        const cx = playerChunkX + dx;
        const cy = playerChunkY + dy;
        keepKeysSet.add(`${cx},${cy}`);
      }
    }

    const chunksToUnloadKeys: string[] = [];
    gr.activeChunks.forEach((chunkKey) => {
      const parts = chunkKey.split(',');
      const cx = parseInt(parts[0], 10);
      const cy = parseInt(parts[1], 10);
      
      const dist = Math.max(Math.abs(cx - playerChunkX), Math.abs(cy - playerChunkY));
      if (dist >= unloadRadius || !keepKeysSet.has(chunkKey)) {
        chunksToUnloadKeys.push(chunkKey);
      }
    });

    // 1. Perform high-performance unloading (Single O(N) filtering)
    if (chunksToUnloadKeys.length > 0) {
      const unloadSet = new Set(chunksToUnloadKeys);

      chunksToUnloadKeys.forEach((chunkKey) => {
        const parts = chunkKey.split(',');
        const cx = parseInt(parts[0], 10);
        const cy = parseInt(parts[1], 10);

        const startX = cx * CHUNK_SIZE_PX;
        const endX = startX + CHUNK_SIZE_PX;
        const startY = cy * CHUNK_SIZE_PX;
        const endY = startY + CHUNK_SIZE_PX;

        const chunk = gr.loadedChunks[layer]?.[chunkKey];
        if (chunk) {
          chunk.resources = gr.resources.filter(
            (node) => node.x >= startX && node.x < endX && node.y >= startY && node.y < endY
          );
          chunk.walls = gr.walls.filter(
            (wall) => wall.x >= startX && wall.x < endX && wall.y >= startY && wall.y < endY
          );
          chunk.turrets = gr.turrets.filter(
            (turret) => turret.x >= startX && turret.x < endX && turret.y >= startY && turret.y < endY
          );
          chunk.enemies = gr.enemies.filter(
            (e) => e.x >= startX && e.x < endX && e.y >= startY && e.y < endY
          );
        }
      });

      // Filter out of memory
      gr.resources = gr.resources.filter(node => {
        const cx = Math.floor(node.x / CHUNK_SIZE_PX);
        const cy = Math.floor(node.y / CHUNK_SIZE_PX);
        return !unloadSet.has(`${cx},${cy}`);
      });
      gr.walls = gr.walls.filter(wall => {
        const cx = Math.floor(wall.x / CHUNK_SIZE_PX);
        const cy = Math.floor(wall.y / CHUNK_SIZE_PX);
        return !unloadSet.has(`${cx},${cy}`);
      });
      gr.turrets = gr.turrets.filter(turret => {
        const cx = Math.floor(turret.x / CHUNK_SIZE_PX);
        const cy = Math.floor(turret.y / CHUNK_SIZE_PX);
        return !unloadSet.has(`${cx},${cy}`);
      });
      gr.enemies = gr.enemies.filter(enemy => {
        const cx = Math.floor(enemy.x / CHUNK_SIZE_PX);
        const cy = Math.floor(enemy.y / CHUNK_SIZE_PX);
        return !unloadSet.has(`${cx},${cy}`);
      });
      gr.backgroundWalls = gr.backgroundWalls.filter(bg => {
        const cx = Math.floor(bg.x / CHUNK_SIZE_PX);
        const cy = Math.floor(bg.y / CHUNK_SIZE_PX);
        return !unloadSet.has(`${cx},${cy}`);
      });
      gr.lavaPools = gr.lavaPools.filter(lv => {
        const cx = Math.floor(lv.x / CHUNK_SIZE_PX);
        const cy = Math.floor(lv.y / CHUNK_SIZE_PX);
        return !unloadSet.has(`${cx},${cy}`);
      });

      gr.activeChunks = gr.activeChunks.filter(k => !unloadSet.has(k));
    }

    // 2. Load visible activeRadius (8 chunk radius) newly visible cells
    const keysToLoad: string[] = [];
    for (let dy = -activeRadius; dy <= activeRadius; dy++) {
      for (let dx = -activeRadius; dx <= activeRadius; dx++) {
        const cx = playerChunkX + dx;
        const cy = playerChunkY + dy;
        const key = `${cx},${cy}`;
        if (!gr.activeChunks.includes(key) || force) {
          keysToLoad.push(key);
        }
      }
    }

    keysToLoad.forEach((chunkKey) => {
      const parts = chunkKey.split(',');
      const cx = parseInt(parts[0], 10);
      const cy = parseInt(parts[1], 10);

      const startX = cx * CHUNK_SIZE_PX;
      const endX = startX + CHUNK_SIZE_PX;
      const startY = cy * CHUNK_SIZE_PX;
      const endY = startY + CHUNK_SIZE_PX;

      if (!gr.loadedChunks[layer]) {
        gr.loadedChunks[layer] = {};
      }

      if (!gr.loadedChunks[layer][chunkKey]) {
        gr.loadedChunks[layer][chunkKey] = worldGenerator.generateChunk(cx, cy, layer);
      }

      const chunk = gr.loadedChunks[layer][chunkKey];

      // Clean to prevent duplicates
      gr.resources = gr.resources.filter(
        (node) => !(node.x >= startX && node.x < endX && node.y >= startY && node.y < endY)
      );
      gr.walls = gr.walls.filter(
        (wall) => !(wall.x >= startX && wall.x < endX && wall.y >= startY && wall.y < endY)
      );
      gr.turrets = gr.turrets.filter(
        (turret) => !(turret.x >= startX && turret.x < endX && turret.y >= startY && turret.y < endY)
      );
      gr.enemies = gr.enemies.filter(
        (e) => !(e.x >= startX && e.x < endX && e.y >= startY && e.y < endY)
      );
      gr.backgroundWalls = gr.backgroundWalls.filter(
        (bg) => !(bg.x >= startX && bg.x < endX && bg.y >= startY && bg.y < endY)
      );
      gr.lavaPools = gr.lavaPools.filter(
        (lv) => !(lv.x >= startX && lv.x < endX && lv.y >= startY && lv.y < endY)
      );

      // Inject active elements
      gr.resources.push(...chunk.resources);
      if (chunk.walls) gr.walls.push(...chunk.walls);
      if (chunk.turrets) gr.turrets.push(...chunk.turrets);
      if (chunk.enemies) gr.enemies.push(...chunk.enemies);
      gr.backgroundWalls.push(...chunk.backgroundWalls);
      gr.lavaPools.push(...chunk.lavaPools);

      if (!gr.activeChunks.includes(chunkKey)) {
        gr.activeChunks.push(chunkKey);
      }
    });
  };

  const transitionToLayer = (nextLayer: 'sky' | 'surface' | 'underground' | 'cavern' | 'underworld') => {
    const gr = gRef.current;
    if (gr.player.portalCooldown > 0) return;

    audio.playXP(); // Event sound

    // Save current active positions before unlinking
    saveCurrentActiveChunksToMemory();

    gr.depthLayer = nextLayer;
    gr.activeChunks = []; // forcing reload
    
    gr.resources = [];
    gr.walls = [];
    gr.turrets = [];
    gr.backgroundWalls = [];
    gr.lavaPools = [];

    // Repopulate coordinates
    reconcileChunks(true);

    gr.player.portalCooldown = 90; // About 1.5 seconds cooldown

    let alertTitle = 'Surface Hills';
    if (nextLayer === 'sky') alertTitle = 'Celestial Sky Islands';
    else if (nextLayer === 'underground') alertTitle = 'Damp Underground Mines';
    else if (nextLayer === 'cavern') alertTitle = 'Magmatic Caverns';
    else if (nextLayer === 'underworld') alertTitle = 'Obsidian Underworld';

    showErrorMsg('Entered: ' + alertTitle);
  };

  // Trigger Canvas Event Hooks
  useEffect(() => {
    if (gameState !== 'PLAYING' && gameState !== 'UPGRADE_SELECT') return;

    let animatedFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high density canvases
    const resizeCanvas = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Mouse events coordinate parsing
    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const rawX = e.clientX - rect.left;
      const rawY = e.clientY - rect.top;
      gRef.current.mouse.x = rawX;
      gRef.current.mouse.y = rawY;
    };

    const handleMouseDown = () => {
      gRef.current.mouse.isDown = true;
      handleActionClick();
    };

    const handleMouseUp = () => {
      gRef.current.mouse.isDown = false;
    };

    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    // Core Gameplay Loop
    const loop = (timestamp: number) => {
      updateGame();
      drawGame(ctx, canvas.width, canvas.height);
      animatedFrameId = requestAnimationFrame(loop);
    };
    animatedFrameId = requestAnimationFrame(loop);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animatedFrameId);
      if (canvas) {
        canvas.removeEventListener('mousemove', handleMouseMove);
        canvas.removeEventListener('mousedown', handleMouseDown);
      }
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [gameState]);

  // Handle Actions (Left Click)
  const handleActionClick = () => {
    const gr = gRef.current;
    
    const rx = canvasRef.current?.getBoundingClientRect();
    if (!rx) return;
    
    // Find absolute location in world coordinates
    const cameraX = gr.player.x - canvasRef.current!.width / 2;
    const cameraY = gr.player.y - canvasRef.current!.height / 2;
    const worldX = gr.mouse.x + cameraX;
    const worldY = gr.mouse.y + cameraY;

    // Dist between click and player
    const distToPlayer = Math.hypot(worldX - gr.player.x, worldY - gr.player.y);

    // Update player facing angle (always face cursor)
    gr.player.angle = Math.atan2(worldY - gr.player.y, worldX - gr.player.x);

    // Get current item and custom category
    const activePreset = CUSTOM_HOTBAR[gr.activeSlot - 1];
    const subIdx = gr.hotbarSubIndices[gr.activeSlot - 1] || 0;
    const slotItem = activePreset[subIdx] || activePreset[0];

    // 1. Toggle Wooden Gates on left-click within range (interactive portal doors!)
    let clickedGate: ProtectiveWall | null = null;
    gr.walls.forEach((wall) => {
      if (wall.type === 'wooden-gate') {
        const dist = Math.hypot(worldX - (wall.x + TILE_SIZE/2), worldY - (wall.y + TILE_SIZE/2));
        if (dist < 46) {
          clickedGate = wall;
        }
      }
    });

    if (clickedGate) {
      const gate = clickedGate as ProtectiveWall;
      gate.isOpen = !gate.isOpen;
      audio.playPlace();
      spawnParticles(gate.x + TILE_SIZE/2, gate.y + TILE_SIZE/2, '#ea580c', 6);
      return; 
    }

    const isMeleeWeapon = slotItem.type === 'weapon' || slotItem.type === 'tool';
    const isBow = slotItem.targetType === 'bow';
    const isCrossbow = slotItem.targetType === 'crossbow';
    const isShield = slotItem.type === 'shield';
    const isWallOrTurret = slotItem.type === 'wall' || slotItem.type === 'turret';

    // 2. Continuous Active Melee Swing Swipes
    if (isMeleeWeapon && slotItem.targetType !== 'torch') {
      let rate = 350;
      const tt = slotItem.targetType;
      if (tt === 'dagger') rate = 180;
      else if (tt === 'sword') rate = 380;
      else if (tt === 'axe') rate = 420;
      else if (tt === 'greatsword') rate = 750;
      else if (tt === 'spear') rate = 500;
      else if (tt === 'pickaxe') rate = 320;

      const now = performance.now();
      if (!gr.player.lastShotTime) gr.player.lastShotTime = 0;
      if (now - gr.player.lastShotTime >= rate) {
        gr.player.lastShotTime = now;
        
        // Setup state for active continuous swing hitbox checks in updateGame loop
        gr.meleeSwingAngle = gr.player.angle;
        gr.meleeSwingProgress = 1.0;
        gr.meleeHitRegister.clear(); // Clear registered entities for this swing
        
        audio.playSwing();

        // Allow players to safely break/dismantle built walls & traps using their Pickaxe/Weapons!
        let cellX = Math.floor(worldX / TILE_SIZE);
        let cellY = Math.floor(worldY / TILE_SIZE);
        let targetWall: ProtectiveWall | null = null;
        
        gr.walls.forEach((w) => {
          if (w.gridX === cellX && w.gridY === cellY) {
            const dist = Math.hypot(w.x + TILE_SIZE/2 - gr.player.x, w.y + TILE_SIZE/2 - gr.player.y);
            if (dist < 92) targetWall = w;
          }
        });

        if (targetWall) {
          const wall = targetWall as ProtectiveWall;
          const mineMultiplier = (tt === 'pickaxe') ? 140 : 35;
          wall.health -= mineMultiplier;
          audio.playPlace();
          spawnParticles(wall.x + TILE_SIZE/2, wall.y + TILE_SIZE/2, '#94a3b8', 6);
          
          if (wall.health <= 0) {
            // Reclaim 50% construction wood/stone/iron material costs!
            if (wall.type === 'wood') gr.player.wood += 3;
            else if (wall.type === 'stone') gr.player.stone += 5;
            else if (wall.type === 'spike-trap') { gr.player.stone += 5; gr.player.iron += 1; }
            else if (wall.type === 'wooden-gate') { gr.player.wood += 7; gr.player.iron += 2; }
            else if (wall.type === 'torch') { gr.player.wood += 1; }

            gr.walls = gr.walls.filter((w) => w.id !== wall.id);
            audio.playXP();
            spawnParticles(wall.x + TILE_SIZE/2, wall.y + TILE_SIZE/2, '#f1f5f9', 12);
          }
        }
      }
    }

    // 3. Ranged Bow and Piercing Crossbow shoots
    if (isBow || isCrossbow) {
      const rate = isBow ? 400 : 850;
      const now = performance.now();
      if (!gr.player.lastShotTime) gr.player.lastShotTime = 0;
      if (now - gr.player.lastShotTime >= rate) {
        gr.player.lastShotTime = now;

        const dx = worldX - gr.player.x;
        const dy = worldY - gr.player.y;
        const len = Math.hypot(dx, dy) || 1;

        const projSpeed = isBow ? 10.5 : 13.5;
        const dmg = isBow ? 25 : 68;

        gr.projectiles.push({
          id: Math.random().toString(),
          type: isBow ? 'arrow' : 'bolt',
          x: gr.player.x + (dx / len) * 22,
          y: gr.player.y + (dy / len) * 22,
          vx: (dx / len) * projSpeed,
          vy: (dy / len) * projSpeed,
          radius: isBow ? 4 : 5.5,
          damage: dmg,
          life: 100,
          maxLife: 100,
          isMeleeAttack: false,
          pierceCount: isBow ? 1 : 4, // heavy crossbow bolt pierces up to 4 targets!
        });

        audio.playShoot();
      }
    }

    // 4. Shields feedback raising raise
    if (isShield) {
      audio.playPlace();
      spawnParticles(gr.player.x + Math.cos(gr.player.angle) * 15, gr.player.y + Math.sin(gr.player.angle) * 15, '#94a3b8', 3);
    }

    // 5. Grid Block Construction
    if (isWallOrTurret || slotItem.targetType === 'torch') {
      if (distToPlayer > PLACEMENT_RANGE) {
        showErrorMsg('Outside building reach boundaries!');
        return;
      }

      const gridX = Math.floor(worldX / TILE_SIZE);
      const gridY = Math.floor(worldY / TILE_SIZE);

      if (
        gr.player.wood < slotItem.costWood ||
        gr.player.stone < slotItem.costStone ||
        gr.player.iron < slotItem.costIron
      ) {
        showErrorMsg('Insufficient resources gathered!');
        return;
      }

      let isOccupied = false;
      const pxGrid = Math.floor(gr.player.x / TILE_SIZE);
      const pyGrid = Math.floor(gr.player.y / TILE_SIZE);
      if (gridX === pxGrid && gridY === pyGrid) {
        showErrorMsg('Cannot construct obstacles on top of yourself!');
        return;
      }

      for (const wall of gr.walls) {
        if (wall.gridX === gridX && wall.gridY === gridY) {
          isOccupied = true;
          break;
        }
      }

      for (const turret of gr.turrets) {
        if (turret.gridX === gridX && turret.gridY === gridY) {
          isOccupied = true;
          break;
        }
      }

      for (const node of gr.resources) {
        if (node.respawnTime === null) {
          const nxGrid = Math.floor(node.x / TILE_SIZE);
          const nyGrid = Math.floor(node.y / TILE_SIZE);
          if (Math.abs(gridX - nxGrid) <= 1 && Math.abs(gridY - nyGrid) <= 1) {
             const nodeDist = Math.hypot((gridX * TILE_SIZE + TILE_SIZE/2) - node.x, (gridY * TILE_SIZE + TILE_SIZE/2) - node.y);
             if (nodeDist < 48) {
              isOccupied = true;
              break;
             }
          }
        }
      }

      if (isOccupied) {
        showErrorMsg('Grid cell is already occupied!');
        return;
      }

      gr.player.wood -= slotItem.costWood;
      gr.player.stone -= slotItem.costStone;
      gr.player.iron -= slotItem.costIron;

      const worldWallX = gridX * TILE_SIZE;
      const worldWallY = gridY * TILE_SIZE;

      audio.playPlace();

      if (slotItem.type === 'wall' || slotItem.targetType === 'torch') {
        const wallType = slotItem.targetType as WallType;
        let maxHp = 180;
        if (wallType === 'stone') maxHp = 420;
        else if (wallType === 'spike-trap') maxHp = 120;
        else if (wallType === 'wooden-gate') maxHp = 220;
        else if (wallType === 'torch') maxHp = 30;

        gr.walls.push({
          id: Math.random().toString(),
          type: wallType,
          gridX,
          gridY,
          x: worldWallX,
          y: worldWallY,
          width: TILE_SIZE,
          height: TILE_SIZE,
          health: maxHp,
          maxHealth: maxHp,
          isOpen: false, // Wooden gates closed by default
        });

        spawnParticles(worldWallX + TILE_SIZE/2, worldWallY + TILE_SIZE/2, '#dddddd', 8);
      } else if (slotItem.type === 'turret') {
        const tType = slotItem.targetType || 'wooden-turret';
        let tRange = 240;
        let tDamage = 13;
        let tCooldown = 35; // fast rate
        if (tType === 'stone-turret') {
          tRange = 200;
          tDamage = 38;
          tCooldown = 90;
        } else if (tType === 'fire-turret') {
          tRange = 280;
          tDamage = 55;
          tCooldown = 120;
        } else if (tType === 'arrow-turret') {
          tRange = 350;
          tDamage = 24;
          tCooldown = 60;
        } else if (tType === 'wall-turret') {
          tRange = 220;
          tDamage = 15;
          tCooldown = 20; // extremely fast machine gun dart fire
        }

        gr.turrets.push({
          id: Math.random().toString(),
          type: tType,
          gridX,
          gridY,
          x: worldWallX,
          y: worldWallY,
          width: TILE_SIZE,
          height: TILE_SIZE,
          range: tRange,
          damage: tDamage,
          fireCooldown: 0,
          maxFireCooldown: Math.max(8, Math.round(tCooldown / gr.player.turretRateMultiplier)),
          angle: 0,
        });
        spawnParticles(worldWallX + TILE_SIZE/2, worldWallY + TILE_SIZE/2, '#99bbee', 10);
      }
    }
  };

  const triggerMeleeSwing = () => {
    const gr = gRef.current;
    gr.meleeSwingAngle = gr.player.angle;
    gr.meleeSwingProgress = 1.0;
  };

  const showErrorMsg = (txt: string) => {
    setPlacementError(txt);
    setTimeout(() => {
      setPlacementError((prev) => (prev === txt ? null : prev));
    }, 2200);
  };

  const checkShieldBlock = (attackerX: number, attackerY: number): boolean => {
    const gr = gRef.current;
    const activePreset = CUSTOM_HOTBAR[gr.activeSlot - 1];
    const subIdx = gr.hotbarSubIndices[gr.activeSlot - 1] || 0;
    const slotItem = activePreset[subIdx] || activePreset[0];

    if (slotItem.type === 'shield') {
      const angleToAttacker = Math.atan2(attackerY - gr.player.y, attackerX - gr.player.x);
      let diffAngle = Math.abs(angleToAttacker - gr.player.angle);
      if (diffAngle > Math.PI) diffAngle = Math.PI * 2 - diffAngle;

      if (diffAngle < 1.15) {
        audio.playPlace(); 
        spawnParticles(gr.player.x + Math.cos(gr.player.angle) * 16, gr.player.y + Math.sin(gr.player.angle) * 16, '#94a3b8', 6);
        
        if (slotItem.targetType === 'iron-shield') {
          gr.enemies.forEach((enemy) => {
            const d = Math.hypot(enemy.x - gr.player.x, enemy.y - gr.player.y);
            if (d < 100) {
              enemy.health -= 18;
              enemy.flashRedTime = 10;
              spawnParticles(enemy.x, enemy.y, '#b91c1c', 4);
            }
          });
        }
        return true;
      }
    }
    return false;
  };

  // State Management Updates (60 FPS tick)
  const updateGame = () => {
    const gr = gRef.current;
    if (gameState !== 'PLAYING') return;

    // Apply juicy hitstop freeze frames for responsive action feel
    if (gr.hitstopFrames > 0) {
      gr.hitstopFrames--;
      return;
    }

    // --- 1. Player Movement & Keyboard Checks ---
    let mx = 0;
    let my = 0;

    if (gr.keys['w'] || gr.keys['arrowup']) my -= 1;
    if (gr.keys['s'] || gr.keys['arrowdown']) my += 1;
    if (gr.keys['a'] || gr.keys['arrowleft']) mx -= 1;
    if (gr.keys['d'] || gr.keys['arrowright']) mx += 1;

    // Normalization length
    if (mx !== 0 || my !== 0) {
      const len = Math.hypot(mx, my);
      const speed = gr.player.speed;
      gr.player.vx = (mx / len) * speed;
      gr.player.vy = (my / len) * speed;
    } else {
      gr.player.vx *= 0.75;
      gr.player.vy *= 0.75;
    }

    // Propose movement coordinates
    const nextX = gr.player.x + gr.player.vx;
    const nextY = gr.player.y + gr.player.vy;

    // Player AABB wall collision checking
    let blockX = false;
    let blockY = false;

    // Boundary restrictions for sky-ceiling and underworld-bedrock (unlimited X and normal Y)
    if (gr.depthLayer === 'sky' && nextY < -12000) blockY = true;
    if (gr.depthLayer === 'underworld' && nextY > 12000) blockY = true;

    // Check with constructive walls
    gr.walls.forEach((wall) => {
      const wLeft = wall.x;
      const wRight = wall.x + TILE_SIZE;
      const wTop = wall.y;
      const wBottom = wall.y + TILE_SIZE;

      const clearance = gr.player.radius - 1;

      if (
        nextY + gr.player.radius > wTop + 2 &&
        nextY - gr.player.radius < wBottom - 2
      ) {
        if (
          (gr.player.x <= wLeft && nextX + clearance >= wLeft) ||
          (gr.player.x >= wRight && nextX - clearance <= wRight)
        ) {
          blockX = true;
        }
      }

      if (
        nextX + gr.player.radius > wLeft + 2 &&
        nextX - gr.player.radius < wRight - 2
      ) {
        if (
          (gr.player.y <= wTop && nextY + clearance >= wTop) ||
          (gr.player.y >= wBottom && nextY - clearance <= wBottom)
        ) {
          blockY = true;
        }
      }
    });

    // Check collisions with solid resource blocks (stones, ores, crystals)
    gr.resources.forEach((node) => {
      if (node.respawnTime !== null) return; // Mined / inactive
      if (!['stone', 'iron', 'gold', 'coal', 'hellstone', 'sky-crystal'].includes(node.type)) return;

      const wLeft = node.x - TILE_SIZE / 2;
      const wRight = node.x + TILE_SIZE / 2;
      const wTop = node.y - TILE_SIZE / 2;
      const wBottom = node.y + TILE_SIZE / 2;

      const clearance = gr.player.radius - 1;

      // Check collision on X projection
      if (
        nextY + gr.player.radius > wTop + 2 &&
        nextY - gr.player.radius < wBottom - 2
      ) {
        if (
          (gr.player.x <= wLeft && nextX + clearance >= wLeft) ||
          (gr.player.x >= wRight && nextX - clearance <= wRight)
        ) {
          blockX = true;
        }
      }

      // Check collision on Y projection
      if (
        nextX + gr.player.radius > wLeft + 2 &&
        nextX - gr.player.radius < wRight - 2
      ) {
        if (
          (gr.player.y <= wTop && nextY + clearance >= wTop) ||
          (gr.player.y >= wBottom && nextY - clearance <= wBottom)
        ) {
          blockY = true;
        }
      }
    });

    if (!blockX) gr.player.x = nextX;
    if (!blockY) gr.player.y = nextY;

    // Tick down portal transition cooldown
    if (gr.player.portalCooldown > 0) {
      gr.player.portalCooldown--;
    }

    // Dyn-load/unload chunks based on current updated player position coords
    reconcileChunks();

    // Portal staircases / Cave entrances collision triggers
    gr.resources.forEach((node) => {
      if (node.respawnTime !== null) return;
      if (!['cave-entrance', 'stairs-up', 'stairs-down'].includes(node.type)) return;

      const dist = Math.hypot(gr.player.x - node.x, gr.player.y - node.y);
      if (dist < 34 && gr.player.portalCooldown <= 0) {
        if (node.type === 'cave-entrance') {
          transitionToLayer('underground');
        } else if (node.type === 'stairs-up') {
          if (gr.depthLayer === 'underworld') transitionToLayer('cavern');
          else if (gr.depthLayer === 'cavern') transitionToLayer('underground');
          else if (gr.depthLayer === 'underground') transitionToLayer('surface');
          else if (gr.depthLayer === 'surface') transitionToLayer('sky');
        } else if (node.type === 'stairs-down') {
          if (gr.depthLayer === 'sky') transitionToLayer('surface');
          else if (gr.depthLayer === 'surface') transitionToLayer('underground');
          else if (gr.depthLayer === 'underground') transitionToLayer('cavern');
          else if (gr.depthLayer === 'cavern') transitionToLayer('underworld');
        }
      }
    });

    // Slowly facing angle tracking to cursor
    const rectX = canvasRef.current?.getBoundingClientRect();
    if (rectX) {
      const cameraX = gr.player.x - canvasRef.current!.width / 2;
      const cameraY = gr.player.y - canvasRef.current!.height / 2;
      const mWorldX = gr.mouse.x + cameraX;
      const mWorldY = gr.mouse.y + cameraY;
      gr.player.angle = Math.atan2(mWorldY - gr.player.y, mWorldX - gr.player.x);
    }

    // Regeneration
    if (gr.player.regenAmount > 0) {
      gr.player.regenTimer++;
      if (gr.player.regenTimer >= 180) { // every 3 seconds at 60fps
        gr.player.regenTimer = 0;
        gr.player.health = Math.min(gr.player.maxHealth, gr.player.health + gr.player.regenAmount);
      }
    }

    // --- 2. Upgrades and EXP gem Pull Magnetics ---
    gr.xpGems.forEach((gem, idx) => {
      const distance = Math.hypot(gem.x - gr.player.x, gem.y - gr.player.y);
      if (distance < 165) {
        // Magnet effect speed
        const speed = Math.max(3, 8 - distance * 0.05);
        const dx = gr.player.x - gem.x;
        const dy = gr.player.y - gem.y;
        const len = Math.hypot(dx, dy) || 1;
        gem.x += (dx / len) * speed;
        gem.y += (dy / len) * speed;

        // Pickup radius check
        if (distance < 24) {
          gr.player.xp += gem.amount;
          audio.playXP();
          setScore((prev) => prev + gem.amount * 10);
          gr.xpGems.splice(idx, 1);

          // Level Up check!
          if (gr.player.xp >= gr.player.xpNeeded) {
            triggerLevelUp();
          }
        }
      }
    });

    // --- 3. Update Projectiles ---
    for (let i = gr.projectiles.length - 1; i >= 0; i--) {
      const p = gr.projectiles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life--;

      let removeProjectile = p.life <= 0;

      // Projectile collision with walls
      if (!removeProjectile) {
        for (const wall of gr.walls) {
          if (
            p.x > wall.x &&
            p.x < wall.x + TILE_SIZE &&
            p.y > wall.y &&
            p.y < wall.y + TILE_SIZE
          ) {
            removeProjectile = true;
            // Spawn stone particles
            const blockColor = wall.type === 'wood' ? '#8b5a2b' : '#777777';
            spawnParticles(p.x, p.y, blockColor, 3);
            break;
          }
        }
      }

      // Projectiles dissolve naturally over life expectancy frames in boundless world

      // Projectile hit enemies (Player's arrows)
      if (p.type === 'arrow' && !removeProjectile) {
        for (let j = gr.enemies.length - 1; j >= 0; j--) {
          const enemy = gr.enemies[j];
          const dist = Math.hypot(p.x - enemy.x, p.y - enemy.y);
          if (dist < enemy.radius + p.radius) {
            // Damage enemy
            enemy.health -= p.damage;
            enemy.flashRedTime = 12;
            spawnParticles(p.x, p.y, '#9e2122', 5);
            
            removeProjectile = true;
            audio.playHurt();

            if (enemy.health <= 0) {
              enemy.isDead = true;
              spawnXPAndRemoveEnemy(enemy, j);
            }
            break;
          }
        }
      }

      // Projectile hit player (Enemy bones/arrows)
      if (p.type === 'enemy-arrow' && !removeProjectile) {
        const dist = Math.hypot(p.x - gr.player.x, p.y - gr.player.y);
        if (dist < gr.player.radius + p.radius) {
          const isBlocked = checkShieldBlock(p.x, p.y);
          if (!isBlocked) {
            gr.player.health -= p.damage;
            spawnParticles(p.x, p.y, '#de3333', 6);
            audio.playHurt();
            if (gr.player.health <= 0) {
              handleGameOver();
            }
          }
          removeProjectile = true;
        }
      }

      if (removeProjectile) {
        gr.projectiles.splice(i, 1);
      }
    }

    // --- 4. Update Autonomous Turrets ---
    gr.turrets.forEach((turret) => {
      if (turret.fireCooldown > 0) {
        turret.fireCooldown--;
      }

      // Seek nearest living enemy
      let nearestDist = turret.range;
      let targetEnemy: Enemy | null = null;

      gr.enemies.forEach((enemy) => {
        const dist = Math.hypot(enemy.x - (turret.x + TILE_SIZE/2), enemy.y - (turret.y + TILE_SIZE/2));
        if (dist < nearestDist) {
          nearestDist = dist;
          targetEnemy = enemy;
        }
      });

      if (targetEnemy) {
        // Aim head
        const tx = (targetEnemy as Enemy).x;
        const ty = (targetEnemy as Enemy).y;
        turret.angle = Math.atan2(ty - (turret.y + TILE_SIZE/2), tx - (turret.x + TILE_SIZE/2));

        // Fire turret matching projectile type
        if (turret.fireCooldown <= 0) {
          turret.fireCooldown = turret.maxFireCooldown;

          const tType = turret.type || 'wooden-turret';
          let projType: 'arrow' | 'dart' | 'fireball' | 'stone-bullet' = 'arrow';
          let projSpeed = 8.5;
          let projRadius = 3.5;
          let projLife = 80;

          if (tType === 'wooden-turret') {
            projType = 'dart';
            projSpeed = 9.0;
            projRadius = 3.0;
            projLife = 75;
          } else if (tType === 'stone-turret') {
            projType = 'stone-bullet';
            projSpeed = 6.8;
            projRadius = 6.0;
            projLife = 60;
          } else if (tType === 'fire-turret') {
            projType = 'fireball';
            projSpeed = 7.5;
            projRadius = 5.5;
            projLife = 100;
          } else if (tType === 'arrow-turret') {
            projType = 'arrow';
            projSpeed = 10.0;
            projRadius = 3.5;
            projLife = 90;
          } else if (tType === 'wall-turret') {
            projType = 'dart';
            projSpeed = 10.5;
            projRadius = 3.0;
            projLife = 65;
          }

          const vx = Math.cos(turret.angle) * projSpeed;
          const vy = Math.sin(turret.angle) * projSpeed;

          gr.projectiles.push({
            id: Math.random().toString(),
            type: projType,
            x: turret.x + TILE_SIZE/2 + Math.cos(turret.angle) * 32,
            y: turret.y + TILE_SIZE/2 + Math.sin(turret.angle) * 32,
            vx,
            vy,
            radius: projRadius,
            damage: turret.damage,
            life: projLife,
            maxLife: projLife,
            isMeleeAttack: false,
          });

          // Play specific action sound
          if (projType === 'fireball') {
            audio.playPlace();
          } else {
            audio.playShoot();
          }
        }
      }
    });

    // --- 5. Update Enemies Logic ---
    for (let i = gr.enemies.length - 1; i >= 0; i--) {
      const enemy = gr.enemies[i];
      let angle = Math.atan2(gr.player.y - enemy.y, gr.player.x - enemy.x);
      enemy.angle = angle;

      if (enemy.flashRedTime > 0) {
        enemy.flashRedTime--;
      }

      // Path blocking - detect if wall sits immediately in forward line within 35px
      const lookAheadDist = 35;
      const targetWorldX = enemy.x + Math.cos(angle) * lookAheadDist;
      const targetWorldY = enemy.y + Math.sin(angle) * lookAheadDist;

      let blockingWall: ProtectiveWall | null = null;
      for (const wall of gr.walls) {
        const cx = Math.max(wall.x, Math.min(targetWorldX, wall.x + TILE_SIZE));
        const cy = Math.max(wall.y, Math.min(targetWorldY, wall.y + TILE_SIZE));
        if (Math.hypot(targetWorldX - cx, targetWorldY - cy) < enemy.radius + 3) {
          blockingWall = wall;
          break;
        }
      }

      // If Creeper is in explosive count-down, freeze and swell
      if (enemy.creeperExplodeTime !== null) {
        enemy.creeperExplodeTime++;
        
        // Swell size logic is drawn during rendering
        if (enemy.creeperExplodeTime >= 75) { // 1.25s of countdown
          // Tick! EXPLODE BOOM!
          triggerCreeperExplosion(enemy.x, enemy.y);
          gr.enemies.splice(i, 1);
          continue;
        }
        continue; // Keep Creeper stationary while preparing explosion
      }

      // Handle Creeper proximity triggers
      if (enemy.type === 'creeper') {
        const distToPlayer = Math.hypot(gr.player.x - enemy.x, gr.player.y - enemy.y);
        let nearTargetObj = distToPlayer < 72;

        if (!nearTargetObj && blockingWall) {
          nearTargetObj = true; // Creeper blows up walls blocking its target
        }

        if (nearTargetObj) {
          enemy.creeperExplodeTime = 0;
          audio.playHiss();
          continue;
        }
      }

      // 5.a Move standard enemies
      let canMove = true;
      if (blockingWall) {
        canMove = false;
        // Melee attack wall at rate
        const now = performance.now();
        if (now - enemy.lastAttackTime > 1100) {
          enemy.lastAttackTime = now;
          blockingWall.health -= enemy.damage;
          audio.playMineHit();

          // Particle chips
          spawnParticles(blockingWall.x + TILE_SIZE/2, blockingWall.y + TILE_SIZE/2, blockingWall.type === 'wood' ? '#8b5a2b' : '#666666', 3);

          if (blockingWall.health <= 0) {
            // Destroy wall block
            const wIdx = gr.walls.findIndex(w => w.id === blockingWall!.id);
            if (wIdx !== -1) gr.walls.splice(wIdx, 1);
          }
        }
      }

      if (canMove) {
        // Skeleton logic is ranged, stays slightly far away from player
        if (enemy.type === 'skeleton') {
          const distToPlayer = Math.hypot(gr.player.x - enemy.x, gr.player.y - enemy.y);
          if (distToPlayer < 240) {
            // backpedal or strafe
            enemy.x -= Math.cos(angle) * enemy.speed * 0.4;
            enemy.y -= Math.sin(angle) * enemy.speed * 0.4;
          } else if (distToPlayer > 310) {
            // walk towards
            enemy.x += Math.cos(angle) * enemy.speed;
            enemy.y += Math.sin(angle) * enemy.speed;
          }

          // Shoot arrow at player
          const now = performance.now();
          if (now - enemy.lastAttackTime > 1900) {
            enemy.lastAttackTime = now;
            // Spawn arrow to player
            const arrowAngle = angle + (Math.random() * 0.15 - 0.07); // Slight offset
            const spd = 6;
            gr.projectiles.push({
              id: Math.random().toString(),
              type: 'enemy-arrow',
              x: enemy.x + Math.cos(arrowAngle) * 20,
              y: enemy.y + Math.sin(arrowAngle) * 20,
              vx: Math.cos(arrowAngle) * spd,
              vy: Math.sin(arrowAngle) * spd,
              radius: 4,
              damage: enemy.damage,
              life: 110,
              maxLife: 110,
              isMeleeAttack: false,
            });
            audio.playShoot();
          }
        } else {
          // Melee (Zombies) tracking & collision with Player
          enemy.x += Math.cos(angle) * enemy.speed;
          enemy.y += Math.sin(angle) * enemy.speed;

          // Melee hit player check
          const distToPlayer = Math.hypot(gr.player.x - enemy.x, gr.player.y - enemy.y);
          if (distToPlayer < enemy.radius + gr.player.radius) {
            const now = performance.now();
            if (now - enemy.lastAttackTime > 1000) {
              enemy.lastAttackTime = now;
              
              const isBlocked = checkShieldBlock(enemy.x, enemy.y);
              if (!isBlocked) {
                gr.player.health -= enemy.damage;
                spawnParticles(gr.player.x, gr.player.y, '#ee2222', 8);
                audio.playHurt();
                if (gr.player.health <= 0) {
                  handleGameOver();
                }
              }
            }
          }
        }
      }
    }

    // --- 6. Update Particles FX ---
    for (let i = gr.particles.length - 1; i >= 0; i--) {
      const p = gr.particles[i] as any;
      p.x += p.vx;
      p.y += p.vy;
      p.life--;

      // Seed 3D properties if not present
      if (p.z === undefined) p.z = 12;
      if (p.vz === undefined) p.vz = Math.random() * 4 + 2;

      // Apply downward gravity pull along vertical Z-axis
      p.vz -= 0.35;
      p.z += p.vz;

      // Bounce off ground (Z <= 0)
      if (p.z <= 0) {
        p.z = 0;
        p.vz = -p.vz * 0.45; // 45% spring bounce energy transfer
        // ground friction slides
        p.vx *= 0.65;
        p.vy *= 0.65;
      }

      if (p.life <= 0) {
        gr.particles.splice(i, 1);
      }
    }

    // --- 7. Resource nodes slow Respawn Timer ticker ---
    gr.resources.forEach((node) => {
      if (node.respawnTime !== null) {
        const timePassed = performance.now() - node.respawnTime;
        if (timePassed >= 30000) { // respawn after 30 seconds
          node.health = node.maxHealth;
          node.respawnTime = null;
        }
      }
    });

    // --- 8. Wave System controller Spawners ---
    if (!gr.isWaveActive) {
      gr.waveTimer--;
      if (gr.waveTimer <= 0) {
        triggerWaveStart();
      }
    } else {
      // Wave active spawner ticker
      if (gr.enemiesToSpawn > 0 && Math.random() < 0.05) {
        spawnWaveEnemy();
      }

      // Check wave completion
      gr.waveCheckCooldown++;
      if (gr.waveCheckCooldown >= 60) {
        gr.waveCheckCooldown = 0;
        if (gr.enemies.length === 0 && gr.enemiesToSpawn === 0) {
          triggerWaveCleared();
        }
      }
    }

    // --- 9. Melee swing sweep progress decrement state & active hitbox checks ---
    if (gr.meleeSwingProgress > 0) {
      gr.meleeSwingProgress -= 0.12; // slow down the sweep slightly for frame precision
      if (gr.meleeSwingProgress <= 0) {
        gr.meleeSwingAngle = null;
      } else {
        const activePreset = CUSTOM_HOTBAR[gr.activeSlot - 1];
        const subIdx = gr.hotbarSubIndices[gr.activeSlot - 1] || 0;
        const slotItem = activePreset[subIdx] || activePreset[0];

        if (slotItem.type === 'weapon' || slotItem.type === 'tool') {
          const tt = slotItem.targetType;
          let dmg = 12;
          let power = 15;
          let range = 80;
          let knockback = 6;

          if (tt === 'dagger') { dmg = 22; power = 6; range = 68; knockback = 4.5; }
          else if (tt === 'sword') { dmg = 38; power = 12; range = 95; knockback = 9.5; }
          else if (tt === 'axe') { dmg = 28; power = 28; range = 90; knockback = 8.0; }
          else if (tt === 'greatsword') { dmg = 78; power = 10; range = 142; knockback = 26.0; }
          else if (tt === 'spear') { dmg = 45; power = 6; range = 175; knockback = 11.0; }
          else if (tt === 'pickaxe') { dmg = 12; power = 18; range = 80; knockback = 6.0; }

          // A. Check Resource Node & Chest hits
          gr.resources.forEach((node) => {
            if (node.respawnTime !== null) return;

            const dist = Math.hypot(node.x - gr.player.x, node.y - gr.player.y);
            if (dist < range + 22) {
              const angleToNode = Math.atan2(node.y - gr.player.y, node.x - gr.player.x);
              let diffAngle = Math.abs(angleToNode - gr.meleeSwingAngle!);
              if (diffAngle > Math.PI) diffAngle = Math.PI * 2 - diffAngle;

              const isSpear = tt === 'spear';
              const maxAngleDiff = isSpear ? 0.38 : 1.35;

              if (diffAngle < maxAngleDiff) {
                const hitKey = `res_${node.id}`;
                if (!gr.meleeHitRegister.has(hitKey)) {
                  gr.meleeHitRegister.add(hitKey);

                  node.health -= power;
                  gr.hitstopFrames = 3;

                  let pColor = '#7a7a7a';
                  if (node.type === 'wood') pColor = '#8b5a2b';
                  else if (node.type === 'iron') pColor = '#eaa231';
                  else if (node.type === 'coal') pColor = '#18181b';
                  else if (node.type === 'gold') pColor = '#fbbf24';
                  else if (node.type === 'hellstone') pColor = '#f97316';
                  else if (node.type === 'sky-crystal') pColor = '#38bdf8';
                  else if (node.type === 'chest') pColor = '#b45309';
                  else if (node.type === 'sky-chest') pColor = '#38bdf8';
                  else if (node.type === 'hellstone-chest') pColor = '#ea580c';

                  spawnParticles(node.x, node.y, pColor, 8, true);

                  if (node.health <= 0) {
                    node.respawnTime = performance.now();
                    let yieldW = 0, yieldS = 0, yieldI = 0;

                    if (node.type === 'wood') yieldW = 12;
                    else if (node.type === 'stone') yieldS = 8;
                    else if (node.type === 'iron') yieldI = 4;
                    else if (node.type === 'coal') { yieldW = 20; yieldS = 15; }
                    else if (node.type === 'gold') { yieldI = 12; yieldS = 15; }
                    else if (node.type === 'hellstone') { yieldI = 25; yieldS = 30; }
                    else if (node.type === 'sky-crystal') { yieldW = 40; yieldS = 40; yieldI = 15; }
                    else if (node.type === 'chest' || node.type === 'sky-chest' || node.type === 'hellstone-chest') {
                      if (node.type === 'chest') { yieldW = 45; yieldS = 45; yieldI = 15; }
                      else if (node.type === 'sky-chest') { yieldW = 92; yieldS = 92; yieldI = 42; }
                      else if (node.type === 'hellstone-chest') { yieldW = 164; yieldS = 164; yieldI = 82; }
                      
                      spawnParticles(node.x, node.y, '#fbbf24', 24);
                      spawnParticles(node.x, node.y, '#38bdf8', 24);
                    }

                    gr.player.wood += yieldW;
                    gr.player.stone += yieldS;
                    gr.player.iron += yieldI;

                    const totalYield = yieldW + yieldS + yieldI;
                    setScore((prev) => prev + totalYield * 4);
                    audio.playXP();
                  } else {
                    audio.playMineHit();
                  }
                }
              }
            }
          });

          // B. Check Enemy Sweep hits
          gr.enemies.forEach((enemy) => {
            const dist = Math.hypot(enemy.x - gr.player.x, enemy.y - gr.player.y);
            if (dist < range + enemy.radius) {
              const angleToEnemy = Math.atan2(enemy.y - gr.player.y, enemy.x - gr.player.x);
              let diffAngle = Math.abs(angleToEnemy - gr.meleeSwingAngle!);
              if (diffAngle > Math.PI) diffAngle = Math.PI * 2 - diffAngle;

              const isSpear = tt === 'spear';
              const maxAngleDiff = isSpear ? 0.38 : 1.35;

              if (diffAngle < maxAngleDiff) {
                const hitKey = `enemy_${enemy.id}`;
                if (!gr.meleeHitRegister.has(hitKey)) {
                  gr.meleeHitRegister.add(hitKey);

                  enemy.health -= dmg;
                  enemy.flashRedTime = 12;
                  gr.hitstopFrames = 3;

                  const kbAngle = Math.atan2(enemy.y - gr.player.y, enemy.x - gr.player.x);
                  enemy.x += Math.cos(kbAngle) * knockback * 3.5;
                  enemy.y += Math.sin(kbAngle) * knockback * 3.5;

                  audio.playHurt();
                  spawnParticles(enemy.x, enemy.y, '#ef4444', 8);
                }
              }
            }
          });
        }
      }
    }

    // --- 10. Leaderboard simulated Bot player changes ---
    const nowTimestamp = performance.now();
    if (nowTimestamp - gr.lastBotUpdate > 4500) {
      gr.lastBotUpdate = nowTimestamp;
      gr.bots.forEach((bot) => {
        if (Math.random() < 0.72) {
          bot.score += Math.floor(Math.random() * 45) + 10;
          if (Math.random() < 0.15) bot.kills += 1;
        }
      });

      // Synchronize back to react state for visual display
      const playerEntry: BotPlayer = {
        id: 'player_id',
        name: 'You Player',
        score: score,
        kills: hudStats.level * 3 + Math.floor(score / 500),
        isPlayer: true,
      };

      const sorted = [...gr.bots, playerEntry].sort((a,b) => b.score - a.score);
      setLeaderboard(sorted);
    }

    // Synchronize HUD stats back to React state smoothly (throttle state setting lightly to prevent react bottlenecks)
    if (Math.random() < 0.3) {
      setHudStats({
        health: Math.max(0, Math.round(gr.player.health)),
        maxHealth: gr.player.maxHealth,
        wood: gr.player.wood,
        stone: gr.player.stone,
        iron: gr.player.iron,
        wave: gr.wave,
        enemiesRemaining: gr.enemies.length + gr.enemiesToSpawn,
        timeToNextWave: gr.isWaveActive ? 0 : Math.max(0, Math.round(gr.waveTimer / 60)),
        isWaveActive: gr.isWaveActive,
        level: gr.player.level,
        xp: gr.player.xp,
        xpNeeded: gr.player.xpNeeded,
        activeSlot: gr.activeSlot,
      });
    }
  };

  // Creeper explosion code
  const triggerCreeperExplosion = (x: number, y: number) => {
    const gr = gRef.current;
    audio.playExplosion();

    // Spawn massive cloud smoke explosion circles
    for (let j = 0; j < 16; j++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = Math.random() * 4.5 + 2;
      gr.particles.push({
        id: Math.random().toString(),
        x,
        y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        size: Math.random() * 15 + 10,
        color: Math.random() < 0.5 ? '#ee5522' : '#777777', // Fire explosion & smoke
        life: Math.random() * 20 + 20,
        maxLife: 40,
      });
    }

    // High damage radius
    const radius = 135;

    // 1. Damage Player
    const distToPlayer = Math.hypot(gr.player.x - x, gr.player.y - y);
    if (distToPlayer < radius) {
      const dmg = Math.round((1 - distToPlayer / radius) * 65);
      gr.player.health -= dmg;
      if (gr.player.health <= 0) {
        handleGameOver();
      }
    }

    // 2. Damage Walls
    for (let i = gr.walls.length - 1; i >= 0; i--) {
      const wall = gr.walls[i];
      const wCenterX = wall.x + TILE_SIZE/2;
      const wCenterY = wall.y + TILE_SIZE/2;
      const dist = Math.hypot(wCenterX - x, wCenterY - y);

      if (dist < radius) {
        const dmg = Math.round((1 - dist / radius) * 160);
        wall.health -= dmg;
        if (wall.health <= 0) {
          gr.walls.splice(i, 1);
        }
      }
    }

    // 3. Damage other nearby Enemies too (Friendly fire chain explosions are fun!)
    const wave = gr.wave;
    for (let i = gr.enemies.length - 1; i >= 0; i--) {
      const enemy = gr.enemies[i];
      const dist = Math.hypot(enemy.x - x, enemy.y - y);
      if (dist < radius && dist > 10) { // Exclude itself
        const dmg = Math.round((1 - dist / radius) * 90);
        enemy.health -= dmg;
        enemy.flashRedTime = 12;

        if (enemy.health <= 0) {
          enemy.isDead = true;
          spawnXPAndRemoveEnemy(enemy, i);
        }
      }
    }
  };

  // Helper trigger particles (fully pooled & zero-allocation)
  const spawnParticles = (x: number, y: number, color: string, count = 5, isGravity = false) => {
    const gr = gRef.current;
    
    // Safety cap active particles to keep game loop buttery smooth at stable 60 FPS
    if (gr.particles.length > 200) {
      gr.particles.splice(0, count);
    }

    for (let i = 0; i < count; i++) {
      const idx = gr.nextParticleIndex;
      const p = gr.particlePool[idx];
      if (p) {
        const angle = Math.random() * Math.PI * 2;
        const spd = Math.random() * 3.5 + 1;
        p.x = x;
        p.y = y;
        p.vx = Math.cos(angle) * spd;
        p.vy = Math.sin(angle) * spd;
        p.size = Math.random() * 5 + 3;
        p.color = color;
        p.life = Math.random() * 15 + 10;
        p.maxLife = 25;
        p.isGravity = isGravity;
        p.z = Math.random() * 15 + 8;
        p.vz = Math.random() * 4 + 3.5;

        if (!gr.particles.includes(p as any)) {
          gr.particles.push(p as any);
        }
      }
      gr.nextParticleIndex = (gr.nextParticleIndex + 1) % gr.particlePool.length;
    }
  };

  const spawnXPAndRemoveEnemy = (enemy: Enemy, index: number) => {
    const gr = gRef.current;
    
    // Spawn green XP gem drops
    const gemCount = enemy.type === 'creeper' ? 3 : enemy.type === 'skeleton' ? 2 : 1;
    for (let k = 0; k < gemCount; k++) {
      gr.xpGems.push({
        id: Math.random().toString(),
        x: enemy.x + (Math.random() * 24 - 12),
        y: enemy.y + (Math.random() * 24 - 12),
        amount: enemy.type === 'zombie' ? 12 : enemy.type === 'skeleton' ? 18 : 22,
        radius: 6,
        color: '#4bfc28',
      });
    }

    // Spawn little blood squirts
    spawnParticles(enemy.x, enemy.y, '#9e2222', 12);
    
    // Remove from array safely
    gr.enemies.splice(index, 1);
    
    // Increment points
    setScore((prev) => prev + 60);
  };

  // Trigger Wave system
  const triggerWaveStart = () => {
    const gr = gRef.current;
    gr.isWaveActive = true;
    audio.playWaveStart();

    // Scale up spawn numbers and density per wave level-up
    gr.enemiesToSpawn = 5 + gr.wave * 4;
    gr.enemiesSpawned = 0;
    gr.waveCheckCooldown = 0;

    // Trigger state changes visually
    setHudStats((prev) => ({
      ...prev,
      isWaveActive: true,
      enemiesRemaining: gr.enemiesToSpawn,
    }));
  };

  const spawnWaveEnemy = () => {
    const gr = gRef.current;
    if (gr.enemiesSpawned >= gr.enemiesToSpawn) return;

    // Choose random point just outside viewport screen distance (approx 800px on circular border)
    const angle = Math.random() * Math.PI * 2;
    const distance = 850;
    const sx = gr.player.x + Math.cos(angle) * distance;
    const sy = gr.player.y + Math.sin(angle) * distance;

    // Let wave enemies spawn freely anywhere around player coordinates in infinite space
    const clampedX = sx;
    const clampedY = sy;

    // Choose Type randomly with wave probability multipliers
    let type: 'zombie' | 'skeleton' | 'creeper' = 'zombie';
    const rand = Math.random();

    if (gr.wave >= 2 && rand > 0.65) {
      type = 'skeleton';
    }
    if (gr.wave >= 3 && rand > 0.85) {
      type = 'creeper';
    } else if (gr.wave >= 4 && rand > 0.75) {
      type = 'creeper';
    }

    // Stats scaling coefficients
    const scale = 1.0 + (gr.wave - 1) * 0.16;

    let hp = 40 * scale;
    let dmg = 10 * scale;
    let speed = 1.6 + Math.random() * 0.4;
    let color = '#3c6e2b'; // zombie dark green
    let radius = 15;

    if (type === 'skeleton') {
      hp = 30 * scale;
      dmg = 12 * scale;
      speed = 1.9;
      radius = 14;
    } else if (type === 'creeper') {
      hp = 30 * scale;
      dmg = 45 * scale; // Explosive high dmg
      speed = 3.3; // Very fast
      radius = 13;
    }

    gr.enemies.push({
      id: Math.random().toString(),
      type,
      x: clampedX,
      y: clampedY,
      radius,
      width: radius * 2,
      height: radius * 3,
      health: hp,
      maxHealth: hp,
      speed,
      damage: dmg,
      angle: 0,
      flashRedTime: 0,
      creeperExplodeTime: null,
      targetWallId: null,
      lastAttackTime: 0,
    });

    gr.enemiesSpawned++;
    if (gr.enemiesSpawned >= gr.enemiesToSpawn) {
      gr.enemiesToSpawn = 0; // stop spawning ticker
    }
  };

  const triggerWaveCleared = () => {
    const gr = gRef.current;
    gr.isWaveActive = false;
    gr.wave++;
    gr.waveTimer = 120 * 60; // 2 minutes (120 seconds) of quiet mining/prep time

    // Re-fill little wood of mercy to prevent getting completely locked with 0 walls
    gr.player.wood += 5;
    gr.player.stone += 3;

    // Notify user
    setHudStats((prev) => ({
      ...prev,
      isWaveActive: false,
      wave: gr.wave,
      timeToNextWave: 120,
    }));
  };

  const handleGameOver = () => {
    setGameState('GAME_OVER');
    audio.playExplosion();

    // Check highscore
    try {
      if (score > highScore) {
        setHighScore(score);
        localStorage.setItem('block_survival_highscore', score.toString());
      }
    } catch {
      // safe bypass write
    }
  };

  // Trigger level up and pauses current cycle for Rogue-lite selector
  const triggerLevelUp = () => {
    const gr = gRef.current;
    gr.player.level++;
    gr.player.xp = 0;
    gr.player.xpNeeded = Math.round(gr.player.xpNeeded * 1.35 + 30);
    audio.playLevelUp();

    // Generate 3 unique upgrade options
    const possibilities: UpgradeOption[] = [
      { id: 'up_hp', name: 'Vitality Core (Max HP)', description: 'Adds +30 to your Max Health immediately and heals you.', type: 'maxHp' },
      { id: 'up_speed', name: 'Engine Exhaust (Move Speed)', description: 'Increases your movement speed by +12%.', type: 'speed' },
      { id: 'up_mine', name: 'Mining Catalyst (Yield)', description: 'Doubles your Pickaxe mining speed and damage.', type: 'miningSpeed' },
      { id: 'up_bow', name: 'Heavy Bowstring (Damage)', description: 'Fires deadly arrows dealing +25% weapon damage closer together.', type: 'weaponDamage' },
      { id: 'up_turret', name: 'Overclock Turrets (Rate)', description: 'Fires automated arrow turrets at a 40% rapid rate.', type: 'turretRate' },
      { id: 'up_heal', name: 'Emergency Medkit', description: 'Instantly restores 100% full health index.', type: 'heal' },
      { id: 'up_regen', name: 'Nano Regen Matrix', description: 'Regenerates +3 Health points automatically every 3 seconds.', type: 'hpRegen' },
    ];

    // Shuffle and pick 3
    const picks = possibilities.sort(() => Math.random() - 0.5).slice(0, 3);
    setUpgradeChoices(picks);
    setGameState('UPGRADE_SELECT');
  };

  const selectUpgrade = (pick: UpgradeOption) => {
    const gr = gRef.current;
    
    if (pick.type === 'maxHp') {
      gr.player.maxHealth += 30;
      gr.player.health += 30;
    } else if (pick.type === 'speed') {
      gr.player.speed *= 1.15;
    } else if (pick.type === 'miningSpeed') {
      gr.player.miningPower = Math.round(gr.player.miningPower * 1.6);
    } else if (pick.type === 'weaponDamage') {
      gr.player.arrowDamage = Math.round(gr.player.arrowDamage * 1.3);
      gr.player.arrowReloadTime = Math.max(150, Math.round(gr.player.arrowReloadTime * 0.8));
    } else if (pick.type === 'turretRate') {
      gr.player.turretRateMultiplier *= 1.4;
      // Overwrite all existing turrets
      gr.turrets.forEach(t => {
        t.maxFireCooldown = Math.round(t.maxFireCooldown * 0.7);
      });
    } else if (pick.type === 'heal') {
      gr.player.health = gr.player.maxHealth;
    } else if (pick.type === 'hpRegen') {
      gr.player.regenAmount += 3;
    }

    audio.playPlace();
    startTransition(() => {
      setGameState('PLAYING');
    });
  };

  // --- HTML5 CANVAS RENDERING PIPELINE ---
  // A modern depth-projected 3D Oblique orthographic projection (Cavalier-Cabinet inspired style)
  // Maps logical ground (x, y) coordinates with height (z) into stunning volumetric voxels.
  const project = (x: number, y: number, z: number) => {
    // We skew back and up: -30% sideways, -55% upwards for every pixel of height (z)
    return {
      x: x - z * 0.35,
      y: y - z * 0.55
    };
  };

  const drawGroundShadow = (ctx: CanvasRenderingContext2D, cx: number, cy: number, rx: number, ry: number) => {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.42)';
    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill();
  };

  const draw3DVoxel = (
    ctx: CanvasRenderingContext2D,
    x: number, y: number, z: number,
    w: number, d: number, h: number,
    baseColor: string,   // Top face color
    leftColor: string,   // Left-front shading
    rightColor: string,  // Right-front shading
    isDamaged = false,
    outlineColor = 'rgba(0, 0, 0, 0.35)'
  ) => {
    // Bottom base vertices projected
    const b0 = project(x, y, z);
    const b1 = project(x + w, y, z);
    const b2 = project(x + w, y + d, z);
    const b3 = project(x, y + d, z);

    // Top roof vertices projected
    const t0 = project(x, y, z + h);
    const t1 = project(x + w, y, z + h);
    const t2 = project(x + w, y + d, z + h);
    const t3 = project(x, y + d, z + h);

    const finalTop = isDamaged ? '#ef4444' : baseColor;
    const finalLeft = isDamaged ? '#dc2626' : leftColor;
    const finalRight = isDamaged ? '#991b1b' : rightColor;

    // Left/Front shaded face
    ctx.fillStyle = finalLeft;
    ctx.beginPath();
    ctx.moveTo(b0.x, b0.y);
    ctx.lineTo(b3.x, b3.y);
    ctx.lineTo(t3.x, t3.y);
    ctx.lineTo(t0.x, t0.y);
    ctx.closePath();
    ctx.fill();

    // Right/Front shaded face
    ctx.fillStyle = finalRight;
    ctx.beginPath();
    ctx.moveTo(b3.x, b3.y);
    ctx.lineTo(b2.x, b2.y);
    ctx.lineTo(t2.x, t2.y);
    ctx.lineTo(t3.x, t3.y);
    ctx.closePath();
    ctx.fill();

    // Top flat face
    ctx.fillStyle = finalTop;
    ctx.beginPath();
    ctx.moveTo(t0.x, t0.y);
    ctx.lineTo(t1.x, t1.y);
    ctx.lineTo(t2.x, t2.y);
    ctx.lineTo(t3.x, t3.y);
    ctx.closePath();
    ctx.fill();

    // Outlines and crisp wireframes
    ctx.strokeStyle = outlineColor;
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.moveTo(t0.x, t0.y);
    ctx.lineTo(t1.x, t1.y);
    ctx.lineTo(t2.x, t2.y);
    ctx.lineTo(t3.x, t3.y);
    ctx.closePath();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(b3.x, b3.y);
    ctx.lineTo(t3.x, t3.y);
    ctx.moveTo(b2.x, b2.y);
    ctx.lineTo(t2.x, t2.y);
    ctx.stroke();
  };

  const draw3DRotatedVoxel = (
    ctx: CanvasRenderingContext2D,
    cx: number, cy: number, cz: number,
    w: number, d: number, h: number,
    angle: number,
    baseColor: string, leftColor: string, rightColor: string,
    isDamaged = false,
    outlineColor = 'rgba(0, 0, 0, 0.4)'
  ) => {
    const getRotatedPoint = (dx: number, dy: number, dz: number) => {
      const rx = dx * Math.cos(angle) - dy * Math.sin(angle);
      const ry = dx * Math.sin(angle) + dy * Math.cos(angle);
      return project(cx + rx, cy + ry, cz + dz);
    };

    const hw = w / 2;
    const hd = d / 2;

    const b0 = getRotatedPoint(-hw, -hd, 0);
    const b1 = getRotatedPoint(hw, -hd, 0);
    const b2 = getRotatedPoint(hw, hd, 0);
    const b3 = getRotatedPoint(-hw, hd, 0);

    const t0 = getRotatedPoint(-hw, -hd, h);
    const t1 = getRotatedPoint(hw, -hd, h);
    const t2 = getRotatedPoint(hw, hd, h);
    const t3 = getRotatedPoint(-hw, hd, h);

    const faces = [
      { pts: [b0, b1, t1, t0], col: leftColor },
      { pts: [b1, b2, t2, t1], col: rightColor },
      { pts: [b2, b3, t3, t2], col: leftColor },
      { pts: [b3, b0, t0, t3], col: rightColor }
    ];

    faces.forEach((f) => {
      ctx.fillStyle = isDamaged ? '#dc2626' : f.col;
      ctx.beginPath();
      ctx.moveTo(f.pts[0].x, f.pts[0].y);
      ctx.lineTo(f.pts[1].x, f.pts[1].y);
      ctx.lineTo(f.pts[2].x, f.pts[2].y);
      ctx.lineTo(f.pts[3].x, f.pts[3].y);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = outlineColor;
      ctx.lineWidth = 1.0;
      ctx.stroke();
    });

    ctx.fillStyle = isDamaged ? '#ef4444' : baseColor;
    ctx.beginPath();
    ctx.moveTo(t0.x, t0.y);
    ctx.lineTo(t1.x, t1.y);
    ctx.lineTo(t2.x, t2.y);
    ctx.lineTo(t3.x, t3.y);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = outlineColor;
    ctx.lineWidth = 1.5;
    ctx.stroke();
  };

  const drawGame = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const gr = gRef.current;
    const timestamp = window.performance?.now() || Date.now();
    
    // Clear canvas background (space void slate)
    ctx.fillStyle = '#060813'; 
    ctx.fillRect(0, 0, width, height);

    // Camera scroll tracking player position (no anymore strict MAP_WIDTH clamps)
    const cameraX = gr.player.x - width / 2;
    const cameraY = gr.player.y - height / 2;

    ctx.save();
    ctx.translate(-cameraX, -cameraY);

    const shadeColor = (color: string, percent: number) => {
      if (!color.startsWith('#')) return color;
      let r = parseInt(color.substring(1, 3), 16) + percent;
      let g = parseInt(color.substring(3, 5), 16) + percent;
      let b = parseInt(color.substring(5, 7), 16) + percent;
      r = Math.min(255, Math.max(0, r));
      g = Math.min(255, Math.max(0, g));
      b = Math.min(255, Math.max(0, b));
      return '#' + r.toString(16).padStart(2, '0') + g.toString(16).padStart(2, '0') + b.toString(16).padStart(2, '0');
    };

    // 1. Render flat ground checkerboard tile cells checking layers at z = 0
    const startCellX = Math.floor(cameraX / TILE_SIZE);
    const endCellX = Math.ceil((cameraX + width) / TILE_SIZE);
    const startCellY = Math.floor(cameraY / TILE_SIZE);
    const endCellY = Math.ceil((cameraY + height) / TILE_SIZE);

    const layer = gr.depthLayer;

    for (let gy = startCellY; gy <= endCellY; gy++) {
      for (let gx = startCellX; gx <= endCellX; gx++) {
        const cx = Math.floor(gx / 16);
        const cy = Math.floor(gy / 16);
        const biome = worldGenerator.getBiome(cx, cy);

        let groundColor = '#1b4332'; // Forest grass green default
        if (layer === 'sky') {
          groundColor = '#0a0d16'; // Deep sky dark cosmic void
        } else if (layer === 'surface') {
          if (biome === 'desert') groundColor = '#b4731d'; // warm golden desert sand
          else if (biome === 'snow') groundColor = '#e2e8f0'; // soft frozen snow white/blue
          else if (biome === 'jungle') groundColor = '#065f46'; // mossy rich jungle green
          else if (biome === 'swamp') groundColor = '#2b3a1a'; // dense deep swamp mud
          else if (biome === 'plains') groundColor = '#3f6212'; // bright plains lime grass
          else if (biome === 'mountains') groundColor = '#4b5563'; // stone grey peaks
        } else if (layer === 'underground') {
          groundColor = '#3f1a04'; // rich damp brown clay
        } else if (layer === 'cavern') {
          groundColor = '#1e293b'; // dark granite slate
        } else if (layer === 'underworld') {
          groundColor = '#0e0404'; // volcanic ash obsidian deep
        }

        // Beautiful checkerboard alternating shade rhythm
        if ((gx + gy) % 2 === 0) {
          ctx.fillStyle = groundColor;
        } else {
          ctx.fillStyle = shadeColor(groundColor, -12);
        }

        // Project oblique flat tile corners
        const p0 = project(gx * TILE_SIZE, gy * TILE_SIZE, 0);
        const p1 = project((gx + 1) * TILE_SIZE, gy * TILE_SIZE, 0);
        const p2 = project((gx + 1) * TILE_SIZE, (gy + 1) * TILE_SIZE, 0);
        const p3 = project(gx * TILE_SIZE, (gy + 1) * TILE_SIZE, 0);

        ctx.beginPath();
        ctx.moveTo(p0.x, p0.y);
        ctx.lineTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.lineTo(p3.x, p3.y);
        ctx.closePath();
        ctx.fill();

        // Soft visual lining grid lines
        ctx.strokeStyle = layer === 'surface' && biome === 'snow' ? '#cbd5e1' : '#141830';
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }
    }

    // Draw Lava Pools bubbling
    gr.lavaPools.forEach((lava) => {
      const p0 = project(lava.x, lava.y, 0);
      const p1 = project(lava.x + lava.width, lava.y, 0);
      const p2 = project(lava.x + lava.width, lava.y + lava.height, 0);
      const p3 = project(lava.x, lava.y + lava.height, 0);

      const bubble = Math.sin(timestamp * 0.007 + lava.x) * 10;
      ctx.fillStyle = bubble > 0 ? '#f97316' : '#ea580c';

      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.lineTo(p3.x, p3.y);
      ctx.closePath();
      ctx.fill();

      // Lava heat glow outlines
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2.0;
      ctx.stroke();
    });

    // 2. Compile Unified Depth-Sort Pipeline (The Painter's Engine)
    // Things with higher y rest closer to front and are drawn on top.
    const renderQueue: any[] = [];

    // Queue Walls
    gr.walls.forEach((wall) => {
      renderQueue.push({
        type: 'wall',
        id: wall.id,
        sortY: wall.y + wall.height,
        data: wall
      });
    });

    // Queue defensive Turrets
    gr.turrets.forEach((turret) => {
      renderQueue.push({
        type: 'turret',
        id: turret.id,
        sortY: turret.y + turret.height,
        data: turret
      });
    });

    // Queue Natural Resources
    gr.resources.forEach((node) => {
      if (node.respawnTime === null) {
        renderQueue.push({
          type: 'resource',
          id: node.id,
          sortY: node.y + (node.type === 'wood' ? 12 : 18),
          data: node
        });
      }
    });

    // Queue Green Gems
    gr.xpGems.forEach((gem) => {
      renderQueue.push({
        type: 'xpGem',
        id: gem.id,
        sortY: gem.y,
        data: gem
      });
    });

    // Queue Active Foes
    gr.enemies.forEach((enemy) => {
      renderQueue.push({
        type: 'enemy',
        id: enemy.id,
        sortY: enemy.y,
        data: enemy
      });
    });

    // Queue Player Steve Avatar
    renderQueue.push({
      type: 'player',
      id: 'player',
      sortY: gr.player.y,
      data: gr.player
    });

    // Queue arrows/projectiles
    gr.projectiles.forEach((p) => {
      renderQueue.push({
        type: 'projectile',
        id: p.id,
        sortY: p.y,
        data: p
      });
    });

    // Queue particle FX sparks
    gr.particles.forEach((p) => {
      renderQueue.push({
        type: 'particle',
        id: p.id,
        sortY: p.y,
        data: p
      });
    });

    // Sort depth ascending so farther renders first
    renderQueue.sort((a, b) => a.sortY - b.sortY);

    // 3. Render Sorted Objects
    renderQueue.forEach((item) => {
      switch (item.type) {
        case 'wall': {
          const wall = item.data;
          
          if (wall.type === 'spike-trap') {
            // Draw slate grey concrete trap slab
            draw3DVoxel(ctx, wall.x, wall.y, 0, wall.width, wall.height, 6, '#475569', '#334155', '#1e293b', false, 'rgba(0,0,0,0.3)');
            // Rise needle spikes
            for (let i = 1; i <= 3; i++) {
              for (let j = 1; j <= 3; j++) {
                const sp = project(wall.x + i * 14, wall.y + j * 14, 6);
                ctx.fillStyle = '#94a3b8';
                ctx.beginPath();
                ctx.moveTo(sp.x, sp.y);
                ctx.lineTo(sp.x - 3, sp.y + 10);
                ctx.lineTo(sp.x + 3, sp.y + 10);
                ctx.closePath();
                ctx.fill();
              }
            }
          }
          else if (wall.type === 'wooden-gate') {
            const isClosed = !wall.isOpen;
            if (isClosed) {
              // Thick solid logs locking
              draw3DVoxel(ctx, wall.x, wall.y, 0, wall.width, wall.height, 46, '#7c2d12', '#9a3412', '#5c1d09', false, 'rgba(0,0,0,0.4)');
              // Gate iron locks decoration
              const boltL = project(wall.x + 8, wall.y + 6, 26);
              const boltR = project(wall.x + wall.width - 14, wall.y + 6, 26);
              ctx.fillStyle = '#fbbf24';
              ctx.fillRect(boltL.x, boltL.y, 5, 8);
              ctx.fillRect(boltR.x, boltR.y, 5, 8);
            } else {
              // Pivoted side support beams with open path gap
              draw3DVoxel(ctx, wall.x, wall.y, 0, 12, wall.height, 46, '#7c2d12', '#5c1d09', '#451a03');
              draw3DVoxel(ctx, wall.x + wall.width - 12, wall.y, 0, 12, wall.height, 46, '#7c2d12', '#5c1d09', '#451a03');
            }
          }
          else if (wall.type === 'torch') {
            drawGroundShadow(ctx, wall.x + wall.width/2, wall.y + wall.height/2, 12, 6);
            // Sconce holder base
            draw3DVoxel(ctx, wall.x + 24, wall.y + 24, 0, 12, 12, 22, '#451a03', '#301201', '#1f0b00');
            
            // Pulsing flame
            const bob = Math.sin(timestamp * 0.016) * 3;
            const fp = project(wall.x + 30, wall.y + 30, 22 + bob);
            
            ctx.fillStyle = '#ea580c';
            ctx.beginPath();
            ctx.arc(fp.x, fp.y, 8, 0, Math.PI * 2);
            ctx.fill();
            
            ctx.fillStyle = '#fbbf24';
            ctx.beginPath();
            ctx.arc(fp.x, fp.y, 4, 0, Math.PI * 2);
            ctx.fill();
          }
          else {
            const isWood = wall.type === 'wood';
            const wallH = 43;
            let topC = '#9a2c44', leftC = '#7a1f33', rightC = '#5c1221';
            if (!isWood) {
              topC = '#475569'; leftC = '#334155'; rightC = '#1e293b';
            }
            draw3DVoxel(ctx, wall.x, wall.y, 0, wall.width, wall.height, wallH, topC, leftC, rightC, false, 'rgba(0,0,0,0.45)');

            if (isWood) {
              // Radial timber concentric accent
              const t0 = project(wall.x + wall.width * 0.22, wall.y + wall.height * 0.22, wallH);
              const t1 = project(wall.x + wall.width * 0.78, wall.y + wall.height * 0.22, wallH);
              const t2 = project(wall.x + wall.width * 0.78, wall.y + wall.height * 0.78, wallH);
              const t3 = project(wall.x + wall.width * 0.22, wall.y + wall.height * 0.78, wallH);
              ctx.strokeStyle = '#b91c1c';
              ctx.lineWidth = 1.5;
              ctx.beginPath();
              ctx.moveTo(t0.x, t0.y);
              ctx.lineTo(t1.x, t1.y);
              ctx.lineTo(t2.x, t2.y);
              ctx.lineTo(t3.x, t3.y);
              ctx.closePath();
              ctx.stroke();
            } else {
              // Mortar lining divides
              ctx.strokeStyle = '#64748b';
              ctx.lineWidth = 1.25;
              const midL = project(wall.x, wall.y + wall.height, wallH / 2);
              const midR = project(wall.x + wall.width, wall.y + wall.height, wallH / 2);
              ctx.beginPath();
              ctx.moveTo(midL.x, midL.y);
              ctx.lineTo(midR.x, midR.y);
              ctx.stroke();
            }
          }

          if (wall.health < wall.maxHealth) {
            const hPt = project(wall.x, wall.y, 50);
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(hPt.x + 8, hPt.y, wall.width - 16, 4);
            ctx.fillStyle = '#10b981';
            ctx.fillRect(hPt.x + 8, hPt.y, (wall.width - 16) * (wall.health / wall.maxHealth), 4);
          }
          break;
        }

        case 'turret': {
          const turret = item.data;
          const cx = turret.x + turret.width / 2;
          const cy = turret.y + turret.height / 2;
          const baseH = 15;
          const tType = turret.type || 'wooden-turret';

          // Tailor colors to turret sub-types
          let baseColor = '#5c4033'; // wooden pine
          let shadowColor = '#3d2b22';
          let capColor = '#2d1e17';
          let barrelCoreColor = '#10b981'; // green dart poison
          let barrelOuterColor = '#7bc676';
          let headColor = '#8b5a2b';
          let headShadowColor = '#5c4033';
          let headCapColor = '#654321';

          if (tType === 'stone-turret') {
            baseColor = '#64748b';
            shadowColor = '#475569';
            capColor = '#334155';
            headColor = '#475569';
            headShadowColor = '#334155';
            headCapColor = '#1e293b';
            barrelCoreColor = '#94a3b8';
            barrelOuterColor = '#475569';
          } else if (tType === 'fire-turret') {
            baseColor = '#7f1d1d'; // dark volcanic bloodred
            shadowColor = '#450a0a';
            capColor = '#180000';
            headColor = '#ef4444';
            headShadowColor = '#991b1b';
            headCapColor = '#4c0519';
            barrelCoreColor = '#f97316'; // orange flame
            barrelOuterColor = '#ef4444';
          } else if (tType === 'arrow-turret') {
            baseColor = '#1e3a8a'; // heavy military blue
            shadowColor = '#172554';
            capColor = '#0f172a';
            headColor = '#2563eb';
            headShadowColor = '#1d4ed8';
            headCapColor = '#1e3a8a';
            barrelCoreColor = '#fbbf24'; // yellow lightning gold
            barrelOuterColor = '#2563eb';
          } else if (tType === 'wall-turret') {
            baseColor = '#bb86fc'; // tech electric purple/pink
            shadowColor = '#3700b3';
            capColor = '#121212';
            headColor = '#cf66fc';
            headShadowColor = '#8833cc';
            headCapColor = '#4a0072';
            barrelCoreColor = '#a855f7';
            barrelOuterColor = '#cf66fc';
          }

          // Pedestal frame base height block
          draw3DVoxel(ctx, turret.x, turret.y, 0, turret.width, turret.height, baseH, baseColor, shadowColor, capColor, false, 'rgba(0,0,0,0.5)');

          // Rotated gun capsule head block
          draw3DRotatedVoxel(ctx, cx, cy, baseH, 32, 32, 12, turret.angle, headColor, headShadowColor, headCapColor);

          // Revolving barrel muzzle pointing outward
          const barBase = project(cx, cy, baseH + 6);
          const barTip = project(cx + Math.cos(turret.angle) * 25, cy + Math.sin(turret.angle) * 25, baseH + 6);

          ctx.strokeStyle = barrelCoreColor;
          ctx.lineWidth = tType === 'stone-turret' ? 9.0 : 6.0;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(barBase.x, barBase.y);
          ctx.lineTo(barTip.x, barTip.y);
          ctx.stroke();

          ctx.strokeStyle = barrelOuterColor; 
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.moveTo(barBase.x, barBase.y);
          ctx.lineTo(barTip.x, barTip.y);
          ctx.stroke();

          if (turret.fireCooldown > 0) {
            const hPt = project(turret.x, turret.y, 38);
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(hPt.x + 10, hPt.y, turret.width - 20, 2);
            ctx.fillStyle = barrelCoreColor;
            ctx.fillRect(hPt.x + 10, hPt.y, (turret.width - 20) * (turret.fireCooldown / turret.maxFireCooldown), 2);
          }
          break;
        }

        case 'resource': {
          const node = item.data;

          if (node.type === 'wood') {
            // Tree base shadow
            drawGroundShadow(ctx, node.x, node.y, 16, 7);

            // Shaded wood trunk
            draw3DVoxel(ctx, node.x - 7, node.y - 7, 0, 14, 14, 38, '#78350f', '#542301', '#2c1000');

            // Volumetric leaf layers
            draw3DVoxel(ctx, node.x - 24, node.y - 24, 38, 48, 48, 18, '#166534', '#14532d', '#052ef6');
            draw3DVoxel(ctx, node.x - 18, node.y - 18, 56, 36, 36, 16, '#15803d', '#166534', '#064e3b');
            draw3DVoxel(ctx, node.x - 12, node.y - 12, 72, 24, 24, 14, '#22c55e', '#15803d', '#14532d');
          }
          else if (node.type === 'stone') {
            drawGroundShadow(ctx, node.x, node.y, 22, 10);
            draw3DVoxel(ctx, node.x - 18, node.y - 18, 0, 36, 36, 26, '#64748b', '#475569', '#334155');
            // stacked boulder accents
            draw3DVoxel(ctx, node.x - 8, node.y - 10, 26, 18, 18, 12, '#94a3b8', '#64748b', '#475569');
          }
          else if (node.type === 'iron') {
            drawGroundShadow(ctx, node.x, node.y, 20, 9);
            // Composite base rock
            draw3DVoxel(ctx, node.x - 16, node.y - 16, 0, 32, 32, 20, '#334155', '#1e293b', '#0f172a');
            // Golden iron crystals sparking up
            draw3DVoxel(ctx, node.x - 10, node.y - 4, 20, 12, 10, 8, '#fbbf24', '#d97706', '#92400e');
            draw3DVoxel(ctx, node.x + 2, node.y - 8, 14, 8, 8, 10, '#fbbf24', '#d97706', '#92400e');
          }
          else if (node.type === 'coal') {
            drawGroundShadow(ctx, node.x, node.y, 20, 8);
            draw3DVoxel(ctx, node.x - 16, node.y - 16, 0, 32, 32, 20, '#27272a', '#1c1917', '#110c0c');
            draw3DVoxel(ctx, node.x - 10, node.y - 6, 20, 10, 10, 10, '#09090b', '#18181b', '#030303');
            draw3DVoxel(ctx, node.x + 2, node.y + 2, 16, 8, 8, 8, '#09090b', '#18181b', '#030303');
          }
          else if (node.type === 'gold') {
            drawGroundShadow(ctx, node.x, node.y, 22, 10);
            draw3DVoxel(ctx, node.x - 18, node.y - 18, 0, 36, 36, 24, '#27272a', '#1e1e24', '#121217');
            draw3DVoxel(ctx, node.x - 8, node.y - 10, 24, 16, 16, 12, '#facc15', '#ca8a04', '#a16207');
            draw3DVoxel(ctx, node.x + 4, node.y + 2, 16, 10, 8, 12, '#fdf087', '#facc15', '#ca8a04');
          }
          else if (node.type === 'hellstone') {
            drawGroundShadow(ctx, node.x, node.y, 24, 11);
            draw3DVoxel(ctx, node.x - 20, node.y - 20, 0, 40, 40, 28, '#1e1b4b', '#090514', '#04020a');
            draw3DVoxel(ctx, node.x - 10, node.y - 10, 28, 20, 20, 16, '#ea580c', '#c2410c', '#7c2d12');
            draw3DVoxel(ctx, node.x + 4, node.y - 4, 18, 12, 12, 14, '#f97316', '#ea580c', '#c2410c');
          }
          else if (node.type === 'sky-crystal') {
            drawGroundShadow(ctx, node.x, node.y, 20, 9);
            draw3DVoxel(ctx, node.x - 16, node.y - 16, 0, 32, 32, 22, '#0f172a', '#020617', '#010206');
            const bob = Math.sin(timestamp * 0.005 + node.x) * 3;
            draw3DVoxel(ctx, node.x - 10, node.y - 10, 22 + bob, 20, 20, 20, '#38bdf8', '#0284c7', '#0369a1');
            draw3DVoxel(ctx, node.x + 2, node.y + 2, 36 + bob, 8, 8, 8, '#e0f2fe', '#38bdf8', '#0284c7');
          }
          else if (node.type === 'cave-entrance') {
            drawGroundShadow(ctx, node.x, node.y, 40, 18);
            draw3DVoxel(ctx, node.x - 30, node.y - 30, 0, 60, 60, 45, '#000000', '#18181b', '#09090b');
            draw3DVoxel(ctx, node.x - 34, node.y - 34, 45, 68, 68, 8, '#71717a', '#52525b', '#3f3f46');
          }
          else if (node.type === 'stairs-up') {
            drawGroundShadow(ctx, node.x, node.y, 32, 14);
            draw3DVoxel(ctx, node.x - 22, node.y - 22, 0, 44, 44, 15, '#78350f', '#451a03', '#270e02');
            draw3DVoxel(ctx, node.x - 14, node.y - 14, 15, 28, 28, 15, '#b45309', '#78350f', '#451a03');
            draw3DVoxel(ctx, node.x - 6, node.y - 6, 30, 12, 12, 15, '#f59e0b', '#d97706', '#b45309');
          }
          else if (node.type === 'stairs-down') {
            drawGroundShadow(ctx, node.x, node.y, 32, 14);
            draw3DVoxel(ctx, node.x - 22, node.y - 22, 0, 44, 44, 10, '#3f3f46', '#27272a', '#18181b');
            draw3DVoxel(ctx, node.x - 14, node.y - 14, 0, 28, 28, 11, '#000000', '#000000', '#000000');
          }
          else if (node.type === 'chest' || node.type === 'sky-chest' || node.type === 'hellstone-chest') {
            drawGroundShadow(ctx, node.x, node.y, 22, 10);
            
            let baseC = '#78350f'; // rich brown
            let lidC = '#b45309';  // lighter wood 
            let lockC = '#fbbf24'; // gleaming gold padlock
            
            if (node.type === 'sky-chest') {
              baseC = '#0369a1'; // deep celestial blue
              lidC = '#38bdf8';  // sparkling sky
              lockC = '#e0f2fe'; // white crystal
            } else if (node.type === 'hellstone-chest') {
              baseC = '#450a0a'; // volcanic charcoal red
              lidC = '#ea580c';  // hot magma orange
              lockC = '#facc15'; // molten brass
            }
            
            // Base voxel chest
            draw3DVoxel(ctx, node.x - 14, node.y - 12, 0, 28, 24, 16, baseC, baseC, baseC, false, 'rgba(0,0,0,0.3)');
            // Raised lid voxel
            draw3DVoxel(ctx, node.x - 15, node.y - 13, 16, 30, 26, 10, lidC, lidC, lidC);
            // Metal lock plate in front
            const lockPt = project(node.x - 3, node.y + 11, 12);
            ctx.fillStyle = lockC;
            ctx.fillRect(lockPt.x, lockPt.y, 6, 8);
          }

          if (node.health < node.maxHealth) {
            const hPt = project(node.x - 20, node.y, 45);
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(hPt.x, hPt.y + 25, 40, 4);
            ctx.fillStyle = '#eab308';
            ctx.fillRect(hPt.x, hPt.y + 25, 40 * (node.health / node.maxHealth), 4);
          }
          break;
        }

        case 'xpGem': {
          const gem = item.data;
          const bob = Math.sin(timestamp * 0.007 + gem.x) * 4.5;
          const gemZ = 5 + bob;

          drawGroundShadow(ctx, gem.x, gem.y, gem.radius * 1.5, gem.radius * 0.6);

          const pt = project(gem.x - gem.radius, gem.y - gem.radius, gemZ);
          ctx.fillStyle = '#4bfc28';
          ctx.fillRect(pt.x, pt.y, gem.radius * 2, gem.radius * 2);
          ctx.fillStyle = '#fff';
          ctx.fillRect(pt.x + 1, pt.y + 1, 2.5, 2.5);
          break;
        }

        case 'enemy': {
          const enemy = item.data;
          const isDamaged = enemy.flashRedTime > 0;
          const walkBob = Math.sin(timestamp * 0.016 + enemy.x) * 4.5;
          const enemyZ = Math.max(0, walkBob);

          drawGroundShadow(ctx, enemy.x, enemy.y, enemy.radius * 1.35, enemy.radius * 0.62);

          if (enemy.type === 'zombie') {
            // Steve Zombie
            draw3DRotatedVoxel(ctx, enemy.x, enemy.y, enemyZ, 16, 22, 20, enemy.angle, '#15803d', '#166534', '#14532d', isDamaged);
            draw3DRotatedVoxel(ctx, enemy.x, enemy.y, enemyZ + 20, 18, 18, 14, enemy.angle, '#166534', '#14532d', '#052e16', isDamaged);
            
            // Zombie outstretched red visual glowing claws
            const wrist = project(enemy.x + Math.cos(enemy.angle) * 12, enemy.y + Math.sin(enemy.angle) * 12, enemyZ + 14);
            ctx.fillStyle = isDamaged ? '#ef4444' : '#15803d';
            ctx.fillRect(wrist.x - 3, wrist.y - 3, 6, 6);
          }
          else if (enemy.type === 'skeleton') {
            // Spinal frame
            draw3DRotatedVoxel(ctx, enemy.x, enemy.y, enemyZ, 8, 12, 18, enemy.angle, '#e2e8f0', '#cbd5e1', '#94a3b8', isDamaged);
            draw3DRotatedVoxel(ctx, enemy.x, enemy.y, enemyZ + 18, 14, 14, 12, enemy.angle, '#f1f5f9', '#e2e8f0', '#cbd5e1', isDamaged);
          }
          else if (enemy.type === 'creeper') {
            let swell = 1.0;
            let isFlashed = isDamaged;
            let colTop = '#15803d', colLeft = '#166534', colRight = '#14532d';

            if (enemy.creeperExplodeTime !== null) {
              const phase = Math.floor(enemy.creeperExplodeTime / 5) % 2;
              isFlashed = phase === 1;
              swell = 1.0 + (enemy.creeperExplodeTime * 0.016);
            }

            // Legs
            draw3DRotatedVoxel(ctx, enemy.x, enemy.y, enemyZ, 18 * swell, 18 * swell, 8 * swell, enemy.angle, colTop, colLeft, colRight, isFlashed);
            // Torso tube
            draw3DRotatedVoxel(ctx, enemy.x, enemy.y, enemyZ + 8 * swell, 12 * swell, 12 * swell, 18 * swell, enemy.angle, colTop, colLeft, colRight, isFlashed);
            // Head
            draw3DRotatedVoxel(ctx, enemy.x, enemy.y, enemyZ + 26 * swell, 18 * swell, 18 * swell, 14 * swell, enemy.angle, colTop, colLeft, colRight, isFlashed);
          }

          if (enemy.health < enemy.maxHealth) {
            const hPt = project(enemy.x, enemy.y, 42);
            ctx.fillStyle = '#450a0a';
            ctx.fillRect(hPt.x - 18, hPt.y, 36, 4);
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(hPt.x - 18, hPt.y, 36 * (enemy.health / enemy.maxHealth), 4);
          }
          break;
        }

        case 'player': {
          const player = gr.player;
          const isMoving = (gr.keys['w'] || gr.keys['ArrowUp'] || gr.keys['s'] || gr.keys['ArrowDown'] || gr.keys['a'] || gr.keys['ArrowLeft'] || gr.keys['d'] || gr.keys['ArrowRight']);
          const walkBob = Math.sin(timestamp * 0.015 + player.x) * 4.0;
          const playerZ = isMoving ? Math.abs(walkBob) : 0;

          drawGroundShadow(ctx, player.x, player.y, 22, 9);

          // Body block
          draw3DRotatedVoxel(
            ctx,
            player.x, player.y, playerZ,
            20, 24, 22,
            player.angle,
            '#0d9488', '#0f766e', '#115e59',
            false,
            'rgba(255,255,255,0.2)'
          );

          // Head block
          draw3DRotatedVoxel(
            ctx,
            player.x, player.y, playerZ + 22,
            18, 18, 14,
            player.angle,
            '#f59e0b', '#d97706', '#b45309'
          );

          // Steve brown hair top layer
          draw3DRotatedVoxel(
            ctx,
            player.x, player.y, playerZ + 33,
            19, 19, 4,
            player.angle,
            '#451a03', '#301201', '#200a00'
          );

          // Steve's glowing blue laser eyes indicators!
          const eyeL = project(player.x + Math.cos(player.angle) * 8 - Math.sin(player.angle) * 4.5, player.y + Math.sin(player.angle) * 8 + Math.cos(player.angle) * 4.5, playerZ + 27);
          const eyeR = project(player.x + Math.cos(player.angle) * 8 + Math.sin(player.angle) * 4.5, player.y + Math.sin(player.angle) * 8 - Math.cos(player.angle) * 4.5, playerZ + 27);
          ctx.fillStyle = '#eaeaff';
          ctx.fillRect(eyeL.x - 2.5, eyeL.y - 1.5, 5, 3);
          ctx.fillRect(eyeR.x - 2.5, eyeR.y - 1.5, 5, 3);
          ctx.fillStyle = '#3b82f6';
          ctx.fillRect(eyeL.x - 1, eyeL.y - 1, 2, 2.5);
          ctx.fillRect(eyeR.x - 1, eyeR.y - 1, 2, 2.5);

          // Tool drawing
          if (gr.meleeSwingAngle !== null) {
            const arcProgress = gr.meleeSwingProgress;
            const swingAngle = gr.meleeSwingAngle;

            ctx.save();
            const swingPos = project(player.x, player.y, playerZ + 12);
            ctx.translate(swingPos.x, swingPos.y);
            ctx.rotate(swingAngle + (1 - arcProgress) * 1.6);

            ctx.fillStyle = '#78350f'; 
            ctx.fillRect(-2, -32, 4, 25);
            ctx.fillStyle = '#cbd5e1'; 
            ctx.fillRect(-12, -35, 24, 6);

            ctx.restore();
          }
          break;
        }

        case 'projectile': {
          const p = item.data;
          const arrowZ = 19;
          const pos = project(p.x, p.y, arrowZ);
          const shPos = project(p.x, p.y, 0);

          drawGroundShadow(ctx, shPos.x, shPos.y, p.type === 'stone-bullet' ? 14 : 10, p.type === 'stone-bullet' ? 6 : 4);

          ctx.save();
          ctx.translate(pos.x, pos.y);
          ctx.rotate(Math.atan2(p.vy, p.vx));

          if (p.type === 'fireball') {
            // Glowing pulsing fireball
            const grad = ctx.createRadialGradient(0, 0, 1, 0, 0, 12);
            grad.addColorStop(0, '#ffffff');
            grad.addColorStop(0.3, '#f97316');
            grad.addColorStop(0.8, '#ef4444');
            grad.addColorStop(1, 'rgba(239, 68, 68, 0)');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(0, 0, 12, 0, Math.PI * 2);
            ctx.fill();
          } else if (p.type === 'stone-bullet') {
            // Dark heavy rounded boulder
            ctx.fillStyle = '#6b7280';
            ctx.strokeStyle = '#374151';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 7, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
          } else if (p.type === 'dart') {
            // Green needle dart
            ctx.strokeStyle = '#22c55e';
            ctx.lineWidth = 3.0;
            ctx.beginPath();
            ctx.moveTo(-8, 0);
            ctx.lineTo(8, 0);
            ctx.stroke();

            ctx.fillStyle = '#10b981';
            ctx.beginPath();
            ctx.moveTo(4, -2);
            ctx.lineTo(8, 0);
            ctx.lineTo(4, 2);
            ctx.closePath();
            ctx.fill();
          } else if (p.type === 'bolt') {
            // Heavy crossbow bolt
            ctx.strokeStyle = '#94a3b8';
            ctx.lineWidth = 3.5;
            ctx.beginPath();
            ctx.moveTo(-16, 0);
            ctx.lineTo(6, 0);
            ctx.stroke();

            ctx.fillStyle = '#334155';
            ctx.beginPath();
            ctx.moveTo(4, -4);
            ctx.lineTo(12, 0);
            ctx.lineTo(4, 4);
            ctx.closePath();
            ctx.fill();
          } else {
            // Default arrow drawing
            ctx.strokeStyle = p.type === 'enemy-arrow' ? '#b45309' : '#a27b5c';
            ctx.lineWidth = 2.0;
            ctx.beginPath();
            ctx.moveTo(-12, 0);
            ctx.lineTo(4, 0);
            ctx.stroke();

            ctx.fillStyle = p.type === 'enemy-arrow' ? '#ec4899' : '#94a3b8';
            ctx.beginPath();
            ctx.moveTo(4, -3);
            ctx.lineTo(11, 0);
            ctx.lineTo(4, 3);
            ctx.closePath();
            ctx.fill();

            ctx.fillStyle = '#ffffff';
            ctx.fillRect(-12, -2, 3, 1.2);
            ctx.fillRect(-12, 0.8, 3, 1.2);
          }

          ctx.restore();
          break;
        }

        case 'particle': {
          const p = item.data;
          const pZ = p.z || 0;
          const pos = project(p.x, p.y, pZ);

          ctx.save();
          ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
          ctx.fillStyle = p.color;
          ctx.fillRect(pos.x - p.size / 2, pos.y - p.size / 2, p.size, p.size);
          ctx.restore();
          break;
        }
      }
    });

    // 4. Melee combat slash ring sweep (vivid Indigo hologram arc)
    if (gr.meleeSwingAngle !== null) {
      const arcProgress = gr.meleeSwingProgress;
      const angle = gr.meleeSwingAngle;

      ctx.save();
      const slashH = 14; 
      ctx.lineWidth = 5;
      ctx.strokeStyle = `rgba(129, 140, 248, ${arcProgress})`; 
      ctx.lineCap = 'round';
      ctx.beginPath();
      
      const steps = 14;
      const startArc = angle - 1.1 * arcProgress;
      const endArc = angle + 1.1 * arcProgress;
      
      for (let s = 0; s <= steps; s++) {
        const theta = startArc + (endArc - startArc) * (s / steps);
        const arcX = gr.player.x + Math.cos(theta) * 54;
        const arcY = gr.player.y + Math.sin(theta) * 54;
        const pt = project(arcX, arcY, slashH);
        if (s === 0) {
          ctx.moveTo(pt.x, pt.y);
        } else {
          ctx.lineTo(pt.x, pt.y);
        }
      }
      ctx.stroke();
      ctx.restore();
    }

    // 5. Render construction Placement snap grid hologram projection
    const activeItem = CUSTOM_HOTBAR[gr.activeSlot - 1][gr.hotbarSubIndices[gr.activeSlot - 1] || 0];
    if (activeItem.type === 'wall' || activeItem.type === 'turret') {
      const worldMouseX = gr.mouse.x + cameraX;
      const worldMouseY = gr.mouse.y + cameraY;
      const dist = Math.hypot(worldMouseX - gr.player.x, worldMouseY - gr.player.y);

      const gridX = Math.floor(worldMouseX / TILE_SIZE);
      const gridY = Math.floor(worldMouseY / TILE_SIZE);
      const withinRange = dist <= PLACEMENT_RANGE;

      const hx = gridX * TILE_SIZE;
      const hy = gridY * TILE_SIZE;

      const p1 = project(hx, hy, 0);
      const p2 = project(hx + TILE_SIZE, hy, 0);
      const p3 = project(hx + TILE_SIZE, hy + TILE_SIZE, 0);
      const p4 = project(hx, hy + TILE_SIZE, 0);

      ctx.lineWidth = 2.0;
      ctx.strokeStyle = withinRange ? 'rgba(74, 222, 128, 0.8)' : 'rgba(239, 68, 68, 0.8)';
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.lineTo(p3.x, p3.y);
      ctx.lineTo(p4.x, p4.y);
      ctx.closePath();
      ctx.stroke();

      ctx.fillStyle = withinRange ? 'rgba(74, 222, 128, 0.22)' : 'rgba(239, 68, 68, 0.22)';
      ctx.fill();
    }

    ctx.restore(); // camera bounds restore
  };

  return (
    <div className="relative w-full h-full flex flex-col md:flex-row bg-[#080a14] text-[#f1f5f9] font-sans select-none overflow-hidden">
      
      {/* 1. START MENU OVERLAY screen */}
      <AnimatePresence>
        {gameState === 'START' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex flex-col items-center justify-start md:justify-center bg-[#050710]/95 p-4 md:p-6 backdrop-blur-md overflow-y-auto"
          >
            <div className="relative max-w-2xl w-full my-auto text-center bg-[#0d1226] border-2 border-indigo-950/80 rounded-2xl p-6 md:p-8 shadow-2xl shadow-indigo-950/40">
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-500 animate-pulse" />
              
              <div className="flex justify-center mb-4">
                <div className="relative p-3 bg-[#141b37] border border-indigo-900/40 rounded-2xl shadow-lg shadow-indigo-500/10">
                  <span className="text-3xl">⚒️</span>
                </div>
              </div>

              <h1 className="text-3xl md:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-400 mb-2 font-mono">
                CRAFT<span className="text-indigo-400">.IO</span> SURVIVAL
              </h1>
              <p className="text-[#a5b4fc]/80 text-xs md:text-sm max-w-md mx-auto mb-5 font-mono">
                Harvest resources, secure your fortifications with walls, upgrade turrets, and survive infinite rogue-lite blocky waves.
              </p>

              {/* Game guidelines */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left mb-6 font-mono text-xs">
                <div className="bg-[#10142a] p-4 rounded-xl border border-indigo-950/45 shadow-inner">
                  <h3 className="text-indigo-400 font-bold mb-2 flex items-center gap-1.5 text-xs md:text-sm">
                    <Compass className="inline w-4 h-4 text-indigo-400" /> Controls
                  </h3>
                  <ul className="space-y-1.5 text-[#a5b4fc]/75">
                    <li>• <b className="text-white">WASD / Arrows</b> : Move Player</li>
                    <li>• <b className="text-white">Mouse Scroll / Keys 1-5</b> : Swap Slots</li>
                    <li>• <b className="text-white">Left Click</b> : Mine, Attack or Build</li>
                  </ul>
                </div>

                <div className="bg-[#10142a] p-4 rounded-xl border border-indigo-950/45 shadow-inner">
                  <h3 className="text-cyan-400 font-bold mb-2 flex items-center gap-1.5 text-xs md:text-sm">
                    <Shield className="inline w-4 h-4 text-cyan-400" /> Categorized Cycling Slots
                  </h3>
                  <ul className="space-y-1 text-[#a5b4fc]/75">
                    <li>• Slot 1: <span className="text-amber-400 font-medium">Melee weapons</span></li>
                    <li>• Slot 2: <span className="text-indigo-400 font-medium">Ranged weapon & Shields</span></li>
                    <li>• Slot 3: <span className="text-emerald-400 font-medium">Fortress Walls & Wooden Gate</span></li>
                    <li>• Slot 4: <span className="text-pink-400 font-medium">5 unique Turrets & Traps</span></li>
                    <li>• Slot 5: <span className="text-cyan-400 font-medium">Steel Pickaxe & Glowing Torch</span></li>
                  </ul>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <button
                  id="btn_play_trigger"
                  onClick={triggerStartGame}
                  className="px-8 py-3 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:from-indigo-400 hover:to-pink-400 text-white font-black text-base rounded-xl shadow-lg shadow-indigo-500/20 hover:shadow-indigo-500/40 transform hover:-translate-y-0.5 transition-all text-center hover:cursor-pointer min-w-[200px] flex items-center justify-center font-mono"
                >
                  <Play className="w-5 h-5 mr-2 fill-current" /> PLAY SURVIVAL
                </button>
                
                {highScore > 0 && (
                  <div className="text-indigo-300 font-mono text-xs border border-indigo-950 bg-indigo-950/40 rounded-xl px-4 py-2">
                    🏆 Highscore Index: <span className="text-white font-bold">{highScore} pts</span>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. GAME OVER SCREEN OVERLAY */}
      <AnimatePresence>
        {gameState === 'GAME_OVER' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#070912]/92 px-4 backdrop-blur-sm"
          >
            <div className="max-w-md w-full text-center bg-[#1c0f14]/95 border border-red-950 rounded-2xl p-8 shadow-2xl shadow-red-950/45 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 to-pink-500" />
              <span className="text-5xl mb-4 block">💀</span>
              <h1 className="text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-pink-500 tracking-wider mb-2 font-mono">
                YOU PERISHED
              </h1>
              <p className="text-red-300/80 font-mono text-sm mb-6">
                The zombie horde breached your fortifications and overran the grid network.
              </p>

              <div className="bg-[#2a131a] p-4 rounded-xl border border-red-950/30 mb-6 font-mono text-left">
                <div className="flex justify-between border-b border-red-950/20 pb-2 mb-2 text-sm">
                  <span className="text-pink-300">Survival Wave:</span>
                  <span className="text-red-300 font-bold">Wave {hudStats.wave}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-pink-300">Total Score:</span>
                  <span className="text-emerald-400 font-bold">{score} pts</span>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <button
                  id="btn_retry_trigger"
                  onClick={triggerStartGame}
                  className="w-full py-3 bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-500 hover:to-pink-500 hover:cursor-pointer text-white font-black rounded-xl flex items-center justify-center shadow-lg shadow-red-950/30 transition-all transform hover:-translate-y-0.5"
                >
                  <RotateCcw className="w-5 h-5 mr-2" /> TRY AGAIN
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. ROGUE-LITE LEVEL SELECTOR OVERLAY */}
      <AnimatePresence>
        {gameState === 'UPGRADE_SELECT' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#070912]/95 p-4 backdrop-blur-md"
          >
            <div className="max-w-xl w-full bg-[#0d101e] border border-indigo-950 rounded-2xl p-6 md:p-8 shadow-2xl shadow-indigo-950/50 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 via-violet-500 to-indigo-600 animate-pulse" />
              <div className="flex items-center justify-between border-b border-indigo-950/40 pb-4 mb-6">
                <div>
                  <h2 className="text-xl md:text-2xl font-black text-white flex items-center font-mono">
                    <Sparkles className="w-5 h-5 text-indigo-400 mr-2" /> LEVEL {hudStats.level} UPGRADE
                  </h2>
                  <p className="text-xs text-[#8ca3db] font-mono">Select 1 technological augment matrix below:</p>
                </div>
                <span className="px-3 py-1 bg-indigo-950 border border-indigo-800/80 text-indigo-400 font-mono text-xs font-extrabold rounded-full">
                  LEVEL UP
                </span>
              </div>

              {/* List picks */}
              <div className="space-y-3 mb-6">
                {upgradeChoices.map((choice) => (
                  <button
                    key={choice.id}
                    onClick={() => selectUpgrade(choice)}
                    className="w-full text-left p-4 bg-[#141a31]/80 hover:bg-[#1b2344] hover:cursor-pointer border border-indigo-950 hover:border-[#818cf8] rounded-xl flex items-start gap-4 transition-all transform hover:-translate-y-0.5 shadow-sm hover:shadow-lg hover:shadow-indigo-950/40"
                  >
                    <div className="p-2.5 bg-indigo-950/80 rounded-lg border border-indigo-800/60 text-indigo-400 mt-1">
                      {choice.type === 'maxHp' && <Plus className="w-5 h-5" />}
                      {choice.type === 'speed' && <Zap className="w-5 h-5" />}
                      {choice.type === 'miningSpeed' && <Wrench className="w-5 h-5" />}
                      {choice.type === 'weaponDamage' && <Target className="w-5 h-5" />}
                      {choice.type === 'turretRate' && <Flame className="w-5 h-5" />}
                      {choice.type === 'heal' && <RotateCcw className="w-5 h-5" />}
                      {choice.type === 'hpRegen' && <Shield className="w-5 h-5" />}
                    </div>
                    <div>
                      <h4 className="text-white font-bold font-mono text-sm md:text-base">{choice.name}</h4>
                      <p className="text-xs text-[#a5b4fc]/70 font-mono leading-relaxed mt-1">{choice.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 4. CANVAS CORE VIEW DISPLAY */}
      <div className="flex-1 relative h-full flex flex-col min-h-0">
        
        {/* TOP HUD ROW BAR */}
        <div className="absolute top-4 left-4 right-4 z-20 pointer-events-none flex flex-wrap gap-2.5 items-start justify-between font-sans">
          
          {/* Main player stats status */}
          <div className="flex flex-col gap-1.5 p-4 bg-[#0d1121]/90 backdrop-blur-md border border-indigo-950/60 rounded-xl pointer-events-auto shadow-lg shadow-black/35 max-w-xs w-full">
            <div className="flex items-center justify-between text-xs font-semibold mb-1">
              <span className="text-[#818cf8] font-mono tracking-wider font-extrabold">PLAYER VITALS</span>
              <span className="text-white font-mono font-bold">HP: {hudStats.health} / {hudStats.maxHealth}</span>
            </div>
            
            {/* HP progress loader bar */}
            <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-900 shadow-inner">
              <div 
                className="h-full bg-gradient-to-r from-teal-500 via-emerald-400 to-green-500 transition-all duration-150 shadow-[0_0_10px_rgba(16,185,129,0.35)]"
                style={{ width: `${(hudStats.health / hudStats.maxHealth) * 100}%` }}
              />
            </div>

            {/* XP progress bar */}
            <div className="flex items-center justify-between text-[10px] text-cyan-400 font-mono mt-1.5">
              <span>LVL {hudStats.level}</span>
              <span>XP: {hudStats.xp} / {hudStats.xpNeeded}</span>
            </div>
            <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-900">
              <div 
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 shadow-[0_0_6px_rgba(52,211,153,0.3)] transition-all duration-300"
                style={{ width: `${Math.min(100, (hudStats.xp / hudStats.xpNeeded) * 100)}%` }}
              />
            </div>
          </div>

          {/* ACTIVE WAVE CLOCK / RADAR */}
          <div className="flex items-center gap-3 p-3.5 bg-[#0d1121]/90 backdrop-blur-md border border-indigo-950/60 rounded-xl pointer-events-auto shadow-lg shadow-black/35">
            <div className="flex flex-col text-right font-mono">
              <span className="text-indigo-400 font-mono tracking-widest font-extrabold text-[10px]/none mb-0.5">SURVIVAL WAVE</span>
              <span className="text-xl font-extrabold text-white">WAVE {hudStats.wave}</span>
            </div>
            
            <div className="h-8 w-px bg-indigo-950/85" />

            <div className="flex flex-col font-mono">
              {hudStats.isWaveActive ? (
                <>
                  <span className="text-red-400 text-[10px]/none font-extrabold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 inline-block animate-ping" /> ACTIVE FOES
                  </span>
                  <span className="text-lg font-extrabold text-[#ef4444] tracking-wider">
                    {hudStats.enemiesRemaining} REMAINING
                  </span>
                </>
              ) : (
                <>
                  <span className="text-emerald-400 text-[10px]/none font-extrabold">SAFE PREPARATION TIMER</span>
                  <span className="text-lg font-extrabold text-emerald-400 tracking-wider font-mono">
                    NEXT WAVE IN {hudStats.timeToNextWave}s
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Premium Resource Badges and Scores display */}
          <div className="flex items-center gap-4 p-3 bg-[#0d1121]/90 backdrop-blur-md border border-indigo-950/60 rounded-xl pointer-events-auto shadow-lg shadow-black/35 font-mono text-sm">
            <div className="flex items-center gap-1"><span className="text-base">🪵</span> <b className="text-white text-xs">{hudStats.wood}</b></div>
            <div className="flex items-center gap-1"><span className="text-base">🧱</span> <b className="text-white text-xs">{hudStats.stone}</b></div>
            <div className="flex items-center gap-1"><span className="text-base">🪙</span> <b className="text-white text-xs">{hudStats.iron}</b></div>
            <div className="h-4 w-px bg-indigo-950/85" />
            <div className="flex flex-col">
              <span className="text-[9px] text-[#fbbf24] uppercase tracking-wider font-bold">Total Index Score</span>
              <span className="text-[#facc15] font-black text-xs">{score} pts</span>
            </div>
          </div>

          {/* Sound control button */}
          <button
            onClick={toggleMute}
            className="p-3.5 bg-[#0d1121]/90 backdrop-blur-md border border-indigo-950/60 text-slate-400 hover:text-white rounded-xl pointer-events-auto hover:cursor-pointer transition-colors shadow-lg shadow-black/35"
          >
            {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
          </button>
        </div>

        {/* BOTTOM RIGHT PLACEMENT WARNING SLIDE */}
        <AnimatePresence>
          {placementError && (
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              className="absolute bottom-28 left-4 z-40 px-4 py-2 bg-red-950/90 border border-red-800 text-red-200 font-mono text-xs rounded-lg shadow-lg flex items-center gap-2"
            >
              <span>❌</span> {placementError}
            </motion.div>
          )}
        </AnimatePresence>

        {/* CANVAS CANVAS REF WRAPPER */}
        <div className="w-full flex-1 min-h-0 bg-[#070912]">
          <canvas
            ref={canvasRef}
            className="w-full h-full block focus:outline-none"
          />
        </div>

        {/* Dynamic description helper float */}
        <div className="absolute bottom-24 left-0 right-0 z-20 flex flex-col items-center pointer-events-none">
          <motion.div
            key={activeSlot + "_" + (hotbarSubIndices[activeSlot - 1] || 0)}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="px-3.5 py-1.5 bg-[#090b14]/90 backdrop-blur-sm border border-indigo-950/80 rounded-xl text-xs font-mono text-[#a5b4fc]/90 mb-1 shadow-lg pointer-events-auto flex items-center gap-2"
          >
            Active: <strong className="text-white font-extrabold">{CUSTOM_HOTBAR[activeSlot - 1][hotbarSubIndices[activeSlot - 1] || 0].name}</strong> — {CUSTOM_HOTBAR[activeSlot - 1][hotbarSubIndices[activeSlot - 1] || 0].description} <span className="text-cyan-400 font-bold ml-1 border border-cyan-500/30 bg-cyan-950/40 rounded px-1.5 py-0.5">Press {activeSlot} to Cycle</span>
          </motion.div>
        </div>

        {/* FLOATING ACTION HOTBAR ROW */}
        <div className="absolute bottom-6 left-0 right-0 z-20 flex justify-center pointer-events-none">
          <div className="flex items-center gap-1.5 md:gap-2.5 p-2 bg-[#090b14]/95 backdrop-blur-md border border-indigo-950/85 rounded-2xl shadow-2xl pointer-events-auto">
            {CUSTOM_HOTBAR.map((preset, slotIdx0) => {
              const subIdx = hotbarSubIndices[slotIdx0] || 0;
              const item = preset[subIdx] || preset[0];
              const active = activeSlot === item.slot;
              const slotNum = item.slot;
              
              const canAfford = 
                hudStats.wood >= item.costWood &&
                hudStats.stone >= item.costStone &&
                hudStats.iron >= item.costIron;

              return (
                <button
                  key={slotNum}
                  onClick={() => changeActiveSlot(slotNum)}
                  className={`relative flex flex-col items-center justify-between w-14 h-14 md:w-16 md:h-16 rounded-xl border-2 transition-all hover:cursor-pointer ${
                    active 
                      ? 'border-indigo-400 bg-indigo-950/70 shadow-lg shadow-indigo-500/10 -translate-y-2 scale-105' 
                      : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  {/* Slot Number key marker */}
                  <span className="absolute top-0.5 left-1 text-[9px] text-[#818cf8] font-mono font-extrabold">
                    {slotNum}
                  </span>

                  {/* Icon illustration */}
                  <div className="flex-1 flex items-center justify-center pt-2">
                    {item.targetType === 'dagger' && <span className="text-xl md:text-2xl">🗡️</span>}
                    {item.targetType === 'sword' && <span className="text-xl md:text-2xl">⚔️</span>}
                    {item.targetType === 'axe' && <span className="text-xl md:text-2xl">🪓</span>}
                    {item.targetType === 'greatsword' && <span className="text-xl md:text-2xl">🗡️</span>}
                    {item.targetType === 'spear' && <span className="text-xl md:text-2xl">🔱</span>}
                    {item.targetType === 'bow' && <span className="text-xl md:text-2xl">🏹</span>}
                    {item.targetType === 'crossbow' && <span className="text-xl md:text-2xl">🎯</span>}
                    {item.targetType === 'wood-shield' && <span className="text-xl md:text-2xl">🛡️</span>}
                    {item.targetType === 'iron-shield' && <span className="text-xl md:text-2xl">🔰</span>}
                    {item.targetType === 'wood' && <span className="text-xl md:text-2xl">🪵</span>}
                    {item.targetType === 'stone' && <span className="text-xl md:text-2xl">🧱</span>}
                    {item.targetType === 'spike-trap' && <span className="text-xl md:text-2xl">🕸️</span>}
                    {item.targetType === 'wooden-gate' && <span className="text-xl md:text-2xl">🚪</span>}
                    {item.targetType === 'pickaxe' && <span className="text-xl md:text-2xl">⚒️</span>}
                    {item.targetType === 'torch' && <span className="text-xl md:text-2xl">🔥</span>}
                  </div>

                  {/* Hotbar item specific label resource count / indicators */}
                  {item.type !== 'tool' && item.type !== 'weapon' && item.type !== 'shield' ? (
                    <div className="pb-1 text-[8px] font-mono text-[#a5b4fc] text-center w-full truncate">
                      {item.costWood > 0 && <span className="mx-0.5">W:{item.costWood}</span>}
                      {item.costStone > 0 && <span className="mx-0.5">S:{item.costStone}</span>}
                      {item.costIron > 0 && <span className="mx-0.5">I:{item.costIron}</span>}
                    </div>
                  ) : (
                    <span className="text-[8px] font-semibold text-[#818cf8] uppercase tracking-wide pb-1 text-center w-full truncate">
                      {item.targetType}
                    </span>
                  )}

                  {/* Afford border indicator overlay */}
                  {(item.costWood > 0 || item.costStone > 0 || item.costIron > 0) && !canAfford && (
                    <div className="absolute inset-0 bg-red-950/40 rounded-xl border border-red-800/30 pointer-events-none" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
}
