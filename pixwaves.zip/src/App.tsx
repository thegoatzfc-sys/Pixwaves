/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import GameBoard from './components/GameBoard';

export default function App() {
  return (
    <div className="w-screen h-screen overflow-hidden flex flex-col bg-[#0b0c0a]">
      <GameBoard />
    </div>
  );
}

