export type ResourceType = 'wood' | 'stone' | 'iron' | 'gold' | 'coal' | 'hellstone' | 'sky-crystal' | 'cave-entrance' | 'stairs-up' | 'stairs-down' | 'chest' | 'sky-chest' | 'hellstone-chest';
export type EnemyType = 'zombie' | 'skeleton' | 'creeper';
export type WallType = 'wood' | 'stone' | 'spike-trap' | 'wooden-gate' | 'torch';
export type ProjectileType = 'arrow' | 'enemy-arrow' | 'sword-swing' | 'bolt' | 'dart' | 'fireball' | 'stone-bullet';

export interface Position {
  x: number;
  y: number;
}

export interface ResourceNode {
  id: string;
  type: ResourceType;
  x: number;
  y: number;
  width: number;
  height: number;
  health: number;
  maxHealth: number;
  respawnTime: number | null; // null if alive, timestamp in performance.now() or time remaining if dead
}

export interface Enemy {
  id: string;
  type: EnemyType;
  x: number;
  y: number;
  radius: number;
  width: number;
  height: number;
  health: number;
  maxHealth: number;
  speed: number;
  damage: number;
  angle: number;
  flashRedTime: number; // Duration of red flashing when hit
  creeperExplodeTime: number | null; // Timer since countdown began
  targetWallId: string | null; // Wall they are currently attacking
  lastAttackTime: number;
  isDead?: boolean;
}

export interface ProtectiveWall {
  id: string;
  type: WallType;
  gridX: number;
  gridY: number;
  x: number;
  y: number;
  width: number;
  height: number;
  health: number;
  maxHealth: number;
  isOpen?: boolean; // For togglable wooden gates
}

export interface Turret {
  id: string;
  type?: string; // 'wooden-turret' | 'stone-turret' | 'fire-turret' | 'arrow-turret' | 'wall-turret'
  gridX: number;
  gridY: number;
  x: number;
  y: number;
  width: number;
  height: number;
  range: number;
  damage: number;
  fireCooldown: number; // in sec/frames
  maxFireCooldown: number; // in sec/frames
  angle: number;
}

export interface Projectile {
  id: string;
  type: ProjectileType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  damage: number;
  life: number;
  maxLife: number;
  isMeleeAttack: boolean;
  pierceCount?: number;
}

export interface XPGem {
  id: string;
  x: number;
  y: number;
  amount: number;
  radius: number;
  color: string;
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
  isGravity?: boolean;
}

export interface BotPlayer {
  id: string;
  name: string;
  score: number;
  kills: number;
  isPlayer?: boolean;
}

export interface UpgradeOption {
  id: string;
  name: string;
  description: string;
  cost?: number;
  type: 'maxHp' | 'speed' | 'miningSpeed' | 'weaponDamage' | 'turretRate' | 'heal' | 'hpRegen';
}

export interface HotbarItem {
  slot: number;
  name: string;
  type: 'tool' | 'weapon' | 'wall' | 'turret';
  targetType?: 'pickaxe' | 'sword' | 'bow' | 'wood' | 'stone' | 'turret';
  costWood: number;
  costStone: number;
  costIron: number;
  description: string;
}
